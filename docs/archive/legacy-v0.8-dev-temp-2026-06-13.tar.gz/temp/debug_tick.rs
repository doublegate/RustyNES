use rustynes_core::Console;
use std::path::PathBuf;

fn main() {
    let rom_path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("..") // crates/
        .join("..") // workspace root
        .join("test-roms")
        .join("cpu")
        .join("cpu_instr_01_implied.nes");

    if !rom_path.exists() {
        eprintln!("ROM not found at {}", rom_path.display());
        return;
    }

    let rom_data = std::fs::read(&rom_path).unwrap();
    let mut console = Console::from_rom_bytes(&rom_data).unwrap();

    println!("Testing cycle-accurate tick() method...");
    println!("Initial: frame={}, cycles={}", console.frame_count(), console.cycles());

    // Run one frame using tick()
    let target_frame = console.frame_count() + 1;
    let mut instr_count = 0;
    let mut tick_count = 0;

    while console.frame_count() < target_frame {
        let (instr_complete, frame_complete) = console.tick();
        tick_count += 1;

        if instr_complete {
            instr_count += 1;
        }

        if frame_complete {
            println!("Frame completed after {} ticks, {} instructions", tick_count, instr_count);
        }

        // Safety check
        if tick_count > 40000 {
            println!("TIMEOUT: {} ticks, {} instructions", tick_count, instr_count);
            println!("Final: frame={}, cycles={}", console.frame_count(), console.cycles());
            break;
        }
    }

    println!("After 1 frame: frame={}, cycles={}", console.frame_count(), console.cycles());

    // Check test status
    let status = console.peek_memory(0x6000);
    println!("Test status at $6000: 0x{:02X}", status);

    if status == 0xFF {
        println!("ERROR: Test ROM not initialized (status=0xFF)");
    }
}
