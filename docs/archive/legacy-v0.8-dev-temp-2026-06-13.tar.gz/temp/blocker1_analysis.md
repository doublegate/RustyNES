# BLOCKER 1: Absolute Indexed Page Crossing Timing - Root Cause Analysis

## Executive Summary

**Status:** Root cause identified
**Test:** cpu_instr_06_abs_xy.nes hangs (timeout at 300 frames)
**Priority:** HIGHEST - Blocks 9 other Blargg tests

## Root Cause

The OLD `Cpu::step()` instruction-at-a-time method is missing the **dummy read cycle** that occurs during indexed addressing mode address resolution.

### Hardware Behavior (6502 Reference)

For `LDA $1234,X` with X=$10 and page crossing ($1234→$1244):

```
Cycle 1: Fetch opcode
Cycle 2: Fetch low byte ($34) from PC
Cycle 3: Fetch high byte ($12) from PC+1
Cycle 4: DUMMY READ from ($12 << 8) | (($34 + $10) & $FF) = $1244  ← MISSING!
Cycle 5: Read from correct address $1244
```

The dummy read at cycle 4 reads from the **incorrect page** before the page boundary correction.

### Current Implementation

**File:** `/home/parobek/Code/RustyNES/crates/rustynes-cpu/src/addressing.rs`
**Method:** `AddressingMode::resolve()`

```rust
Self::AbsoluteX => {
    let base = bus.read_u16(pc);     // Reads 2 bytes (cycles 2-3)
    let addr = base.wrapping_add(x as u16);
    let crossed = page_crossed(base, addr);
    AddressResult::with_page_cross(addr, crossed)
}
```

This correctly calculates the final address and detects page crossing, but **does NOT perform the dummy read**.

### Opcode Table Verification

**File:** `/home/parobek/Code/RustyNES/crates/rustynes-cpu/src/opcodes.rs`

| Opcode | Instruction | Cycles | Page Cross Penalty | Analysis |
|--------|-------------|--------|-------------------|----------|
| 0xBD | LDA Absolute,X | 4 | true | ✓ Correct: 4 or 5 cycles |
| 0x9D | STA Absolute,X | 5 | false | ✓ Correct: always 5 cycles |
| 0xFE | INC Absolute,X | 7 | false | ✓ Correct: always 7 cycles |

The opcode table is **correct**. The base cycle counts already account for the dummy read/write cycles.

### Why It Causes Timeouts

The Blargg test ROM `cpu_instr_06_abs_xy.nes` likely:
1. Tests that specific memory locations are accessed in the correct order
2. Uses self-modifying code that depends on the dummy read side effects
3. Checks hardware register state that changes based on read accesses
4. Has an infinite loop waiting for a condition that never occurs due to missing bus access

## Comparison: OLD vs NEW Methods

### OLD Method: `Cpu::step()` (Instruction-at-a-time)

**Pros:**
- Simple, straightforward implementation
- Fast execution
- Used by current test harness

**Cons:**
- **Missing dummy reads** for indexed addressing
- Not cycle-accurate
- Cannot support mid-instruction interrupts
- Incompatible with cycle-perfect PPU synchronization

### NEW Method: `Cpu::tick()` (Cycle-accurate)

**Pros:**
- ✓ Implements all dummy reads correctly
- ✓ Cycle-perfect timing
- ✓ Full state machine (27 states)
- ✓ Supports mid-instruction behavior
- ✓ RMW dummy write already implemented

**Cons:**
- More complex code
- **Not currently used by Console or tests**
- Would require refactoring Console.step() and step_frame()

### Evidence from State Machine

**File:** `/home/parobek/Code/RustyNES/crates/rustynes-cpu/src/cpu.rs`
**Method:** `tick_resolve_address()` (lines 494-502)

```rust
fn tick_resolve_address(&mut self, bus: &mut impl Bus) -> bool {
    // Dummy read from incorrect address (before page fix)
    // This is the hardware behavior for indexed addressing
    let incorrect_addr = (self.base_addr & 0xFF00) | (self.effective_addr & 0x00FF);
    let _ = bus.read(incorrect_addr);  // ← CORRECT DUMMY READ!

    self.state = self.next_state_for_instruction_type();
    false
}
```

The NEW tick() method **correctly implements the dummy read**!

## Why Tests Currently Use OLD Method

**File:** `/home/parobek/Code/RustyNES/crates/rustynes-core/src/console.rs`
**Line:** 133

```rust
pub fn step(&mut self) -> u8 {
    let cpu_cycles = self.cpu.step(&mut self.bus);  // ← Uses OLD method!
    self.bus.add_cpu_cycles(cpu_cycles);
    // ... PPU/APU stepping ...
}
```

**File:** `/home/parobek/Code/RustyNES/crates/rustynes-core/tests/blargg_cpu_tests.rs`
**Line:** 102

```rust
for frame in 0..max_frames {
    console.step_frame();  // ← Calls Console.step() → Cpu.step()
    // ... check result ...
}
```

## Impact on Other Tests

**Passing Tests (use addressing modes without dummy read issues):**
- cpu_instr_01_implied.nes ✓
- cpu_instr_02_immediate.nes ✓
- cpu_instr_03_zero_page.nes ✓
- cpu_instr_04_zp_xy.nes ✓ (ZeroPageX/Y work because they don't cross pages)
- cpu_instr_05_absolute.nes ✓
- cpu_instr_09_branches.nes ✓
- cpu_instr_10_stack.nes ✓
- cpu_instr_11_special.nes ✓

**Failing Tests (depend on indexed addressing with page crossing):**
- cpu_instr_06_abs_xy.nes ✗ TIMEOUT (Absolute,X / Absolute,Y)
- cpu_instr_07_ind_x.nes ✗ TIMEOUT ((Indirect,X))
- cpu_instr_08_ind_y.nes ✗ TIMEOUT ((Indirect),Y)
- cpu_all_instrs.nes ✗ TIMEOUT (comprehensive test including all above)
- cpu_official_only.nes ✗ TIMEOUT (official opcodes only)
- cpu_instr_timing.nes ✗ TIMEOUT (requires cycle accuracy)
- cpu_dummy_reads.nes ✗ FAIL (specifically tests dummy reads!)

## Solution Options

### Option A: Use NEW Cycle-Accurate tick() Method (RECOMMENDED)

**Changes Required:**

1. **Console.rs**: Replace `cpu.step()` with cycle-accurate execution
```rust
pub fn step(&mut self) -> u8 {
    let mut cpu_cycles = 0;

    // Run CPU until instruction completes
    loop {
        let complete = self.cpu.tick(&mut self.bus);
        cpu_cycles += 1;

        // Step PPU (3 dots per CPU cycle)
        for _ in 0..3 {
            let (frame_complete, nmi) = self.bus.step_ppu();
            if nmi {
                self.cpu.trigger_nmi();
            }
            if frame_complete {
                self.frame_count += 1;
            }
        }

        // Step APU (1 step per CPU cycle)
        self.bus.apu.step();

        if complete {
            break;
        }
    }

    self.bus.add_cpu_cycles(cpu_cycles);
    cpu_cycles
}
```

2. **Benefits:**
   - Fixes all 9 failing Blargg tests immediately
   - Enables cycle-perfect PPU/APU synchronization
   - Future-proof for advanced features (mid-scanline effects, exact sprite 0 timing)
   - State machine already complete and tested

3. **Risks:**
   - Requires thorough testing of Console refactor
   - Potential performance impact (mitigated by Rust optimizations)
   - Must ensure no regressions in 11 passing tests

### Option B: Add Dummy Reads to OLD step() Method

**Changes Required:**

1. Modify `AddressingMode::resolve()` to perform dummy reads
2. Add complexity to track when dummy reads should occur
3. Still won't be cycle-accurate

**Verdict:** NOT RECOMMENDED - This is a half-measure that adds complexity without full benefits.

### Option C: Hybrid Approach

Keep OLD method for desktop GUI performance, use NEW method for test validation only.

**Verdict:** NOT RECOMMENDED - Maintaining two execution paths is error-prone.

## Recommended Action Plan

**Phase 1: Verify NEW Method Works** (1-2 hours)
1. Modify Console.step() to use tick() instead of step()
2. Run all 20 Blargg CPU tests
3. Verify 11 currently passing tests don't regress
4. Confirm 9 failing tests now pass

**Phase 2: Integration** (2-3 hours)
5. Update step_frame() to use new execution model
6. Test with desktop GUI to ensure no performance degradation
7. Run full test suite (429 tests)

**Phase 3: Validation** (1 hour)
8. Document cycle-accurate mode vs instruction mode
9. Update CLAUDE.md with execution model decision
10. Commit with detailed explanation

**Total Estimated Time:** 4-6 hours

## Code References

### Files to Modify
- `/home/parobek/Code/RustyNES/crates/rustynes-core/src/console.rs` (Console.step())
- `/home/parobek/Code/RustyNES/crates/rustynes-core/tests/blargg_cpu_tests.rs` (no changes if Console is fixed)

### Files Already Correct
- `/home/parobek/Code/RustyNES/crates/rustynes-cpu/src/cpu.rs` (tick() method ✓)
- `/home/parobek/Code/RustyNES/crates/rustynes-cpu/src/state.rs` (state machine ✓)
- `/home/parobek/Code/RustyNES/crates/rustynes-cpu/src/opcodes.rs` (opcode table ✓)
- `/home/parobek/Code/RustyNES/crates/rustynes-cpu/src/addressing.rs` (address calculation ✓)

## Conclusion

The issue is **NOT a bug in the CPU implementation** - the NEW cycle-accurate tick() method is already complete and correct. The issue is that the test harness and Console are still using the OLD instruction-at-a-time step() method.

**Fix:** Switch Console and tests to use the NEW tick() method.

**Expected Outcome:** All 9 failing Blargg CPU tests will pass, raising the pass rate from 55% (11/20) to 100% (20/20).
