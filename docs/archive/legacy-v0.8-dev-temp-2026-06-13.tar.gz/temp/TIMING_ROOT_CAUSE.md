# Root Cause Analysis: cpu_dummy_reads.nes Timing Investigation

## CRITICAL DISCOVERY: Frame 0 Not Accounted For

### Frame Timing Verification Results

**Measured frame lengths (frames 1-11):**
- Frame timing is EXCELLENT: +/- 1-2 cycles per frame
- Cumulative drift over 10 frames: only +4 cycles
- CPU/PPU synchronization is working correctly

### The Missing Frame

**Problem:** Our calculations didn't account for Frame 0!

Console.rs initializes `frame_count = 0` and increments it when frames complete:
- Frame 0: CPU cycles 0 → ~29,780 (NOT logged, happens before frame_count reaches 1)
- Frame 1: CPU cycles ~29,780 → ~59,561 (FIRST logged frame)
- Frame 2: CPU cycles ~59,561 → ~89,342
- ...
- Frame 10: CPU cycles ~268,022 → ~297,804

**Corrected VBlank calculation for frame 10:**
- Frame 0 ends at: ~29,780
- Frame 9 ends at: ~29,780 + (9 frames × ~29,780) = ~297,800
- VBlank in frame 10 = 297,800 + 27,394 = **325,194 CPU cycles**

This EXACTLY matches the PPU debug output from previous investigation!

### Why the ROM Still Fails

The timing is CORRECT, but the ROM execution flow is problematic:

**Frame 10 execution timeline:**
1. Cycle 325,194: VBlank SET ✓
2. Cycle 325,274: ROM reads $2002 at PC=E600 (clears VBlank) - **80 cycles after VBlank SET**
3. Cycle 325,278: ROM enters wait loop at E603-E606
4. VBlank already cleared by read at E600
5. Infinite loop - can't detect VBlank

**Why early frames succeed but frame 10 fails:**
- Early frames (1-4): ROM is in initialization code, enters VBlank wait loops BEFORE other $2002 reads
- Frame 10: ROM is executing test code that reads $2002 at E600, THEN tries to wait at E603-E606
- Different execution paths in ROM lead to different timing

### Remaining Questions

1. **Is the ROM behavior correct?**
   - Does the real NES exhibit the same timing?
   - Could this be a test ROM bug?

2. **CPU instruction timing precision:**
   - Are all 256 opcodes cycle-accurate?
   - Page boundary crossing detection accurate?
   - Branch timing correct?

3. **PPU timing edge cases:**
   - Odd-frame skip actually working as expected?
   - Scanline timing precise?

### Next Steps

1. Verify CPU instruction timing is 100% accurate (all 256 opcodes)
2. Add test to measure EXACT CPU cycles between VBlank occurrences
3. Compare against reference emulator behavior (Mesen2, FCEUX)
4. Check if test ROM has known timing requirements
