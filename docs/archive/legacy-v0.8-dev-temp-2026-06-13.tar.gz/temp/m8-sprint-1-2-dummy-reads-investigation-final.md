# M8 Sprint 1 & 2: Dummy Reads Investigation - Final Report

**Date:** December 20, 2025
**Time Invested:** 3+ hours
**Status:** Incomplete - Requires deeper architectural changes

---

## Summary

Investigated failing test ROMs related to CPU dummy read/write operations. Identified root cause as missing bus-level dummy read operations in indexed addressing modes, but initial implementation caused test timeouts due to complex interaction between cycle counting and bus operations.

---

## Test Failures Investigated

| Test | Initial Status | After Fix Attempt | Root Cause |
|------|----------------|-------------------|------------|
| cpu_dummy_reads.nes | FAIL (0xFF) | Still FAIL (0xFF) | Bus-level dummy reads missing |
| cpu_dummy_writes_ppumem.nes | TIMEOUT (frame 227) | Not retested | Side effects of dummy operations |
| cpu_instr_06_abs_xy.nes | TIMEOUT | TIMEOUT (worse) | Added dummy reads broke timing |

---

## Key Findings

### 1. Cycle Counts Are Correct

The opcode table in `opcodes.rs` has correct cycle counts:
- STA Abs,X: 5 cycles (no page cross penalty) ✅
- ASL Abs,X: 7 cycles (no page cross penalty) ✅
- LDA Abs,X: 4 cycles + 1 if page crossed ✅
- LDA ZP,X: 4 cycles ✅

### 2. RMW Dummy Writes Are Implemented

All Read-Modify-Write instructions already perform dummy writes:
```rust
let value = bus.read(addr);
bus.write(addr, value); // Dummy write
let new_value = modify(value);
bus.write(addr, new_value); // Real write
```

This is correct for INC, DEC, ASL, LSR, ROL, ROR, and all unofficial RMW opcodes.

### 3. Problem: Bus-Level Dummy Reads Missing

The 6502 hardware performs dummy reads during indexed addressing for timing alignment:

**Absolute,X/Y:**
```
LDA $1234,X where X=$10

Cycle 1: Fetch opcode
Cycle 2: Fetch address low $34
Cycle 3: Fetch address high $12
Cycle 4: DUMMY READ from ($1234 + $10) & $XXFF (address without carry)
Cycle 5: Read from $1244 (only if page crossed)

If no page cross: dummy read returns correct value, no cycle 5 needed
If page crossed: dummy read returns wrong value, cycle 5 gets correct value
```

**Current Implementation:**
```rust
// addressing.rs - resolve()
Self::AbsoluteX => {
    let base = bus.read_u16(pc);
    let addr = base.wrapping_add(x as u16);
    let crossed = page_crossed(base, addr);
    AddressResult::with_page_cross(addr, crossed)  // NO DUMMY READ!
}
```

The addressing resolution calculates the correct address but NEVER performs the hardware dummy read operation.

### 4. Why This Matters

Dummy reads have observable side effects:
1. **PPU Registers:** Reading $2007 (PPUDATA) increments PPUADDR
2. **Bus Conflicts:** Some mappers react to reads from specific addresses
3. **Open Bus:** Reads update the data bus latch
4. **Test ROMs:** Blargg tests explicitly verify these side effects occur

The `cpu_dummy_writes_ppumem.nes` test specifically checks that dummy writes to PPU memory trigger PPUADDR increment and other PPU behavior.

---

## Implementation Attempt

### Changes Made

Modified `addressing.rs` to perform dummy reads:

```rust
Self::AbsoluteX => {
    let base = bus.read_u16(pc);
    let addr = base.wrapping_add(x as u16);
    let crossed = page_crossed(base, addr);

    // Dummy read from address without carry
    let addr_no_carry = (base & 0xFF00) | ((base + x as u16) & 0x00FF);
    let _ = bus.read(addr_no_carry);  // ADDED

    AddressResult::with_page_cross(addr, crossed)
}
```

Similar changes for AbsoluteY, IndirectIndexedY, ZeroPageX, ZeroPageY.

### Results

| Test | Before | After | Change |
|------|--------|-------|--------|
| cpu_instr_02_immediate | PASS | PASS | No regression ✅ |
| nestest.nes golden log | PASS | PASS | No regression ✅ |
| cpu_dummy_reads.nes | FAIL | Still FAIL | No improvement ❌ |
| cpu_instr_06_abs_xy.nes | TIMEOUT | TIMEOUT | No improvement or worse ❌ |

### Why It Didn't Work

The issue is subtle timing interaction:

1. **Opcode Table Cycles:** Already include dummy read timing (e.g., LDA Abs,X = 4 cycles base)
2. **Dummy Read Operation:** Now performed but doesn't add cycles (correct)
3. **But:** Some reads from specific addresses might trigger unexpected behavior
4. **Result:** Tests timeout, suggesting infinite loop or wrong execution path

---

## Architecture Problem

The current CPU architecture has a fundamental issue:

```rust
// cpu.rs - step()
let opcode = bus.read(self.pc);
let info = &OPCODE_TABLE[opcode as usize];
let extra_cycles = self.execute_opcode(opcode, info.addr_mode, bus);
let total_cycles = info.cycles + extra_cycles;
```

The cycle counting happens AFTER the instruction executes. But `resolve()` is called DURING execution, and it's now performing bus reads that might have side effects BEFORE we know if we should be in that execution path.

Example scenario that could break:
1. Instruction reads from address $4015 (APU status)
2. This read clears the DMC interrupt flag
3. But it was a dummy read that shouldn't have cleared the flag!
4. Now IRQ timing is broken
5. Test gets stuck waiting for an IRQ that never comes

---

## Correct Solution (Not Implemented)

The proper fix requires restructuring how addressing modes work:

### Option A: Separate Read/Write Addressing

Create distinct addressing resolution for reads vs writes:
```rust
fn resolve_absolute_x_read(&mut self, bus: &mut impl Bus) -> (u16, u8) {
    let base = bus.read_u16(self.pc);
    self.pc += 2;
    let addr = base.wrapping_add(self.x as u16);

    if page_crossed(base, addr) {
        let addr_no_carry = (base & 0xFF00) | ((base + self.x as u16) & 0x00FF);
        let _ = bus.read(addr_no_carry); // Dummy read
        (addr, 1) // +1 cycle
    } else {
        // No page cross: the "dummy" read IS the real read
        (addr, 0)
    }
}

fn resolve_absolute_x_write(&mut self, bus: &mut impl Bus) -> u16 {
    let base = bus.read_u16(self.pc);
    self.pc += 2;
    let addr = base.wrapping_add(self.x as u16);

    // ALWAYS do dummy read for writes
    let addr_no_carry = (base & 0xFF00) | ((base + self.x as u16) & 0x00FF);
    let _ = bus.read(addr_no_carry);

    addr
}
```

### Option B: Bus Operation Logging

Instead of actually performing reads, log which addresses WOULD be read and let the bus implementation decide if side effects should occur:
```rust
trait Bus {
    fn read(&mut self, addr: u16) -> u8;
    fn read_dummy(&mut self, addr: u16) -> u8; // Might not trigger all side effects
    fn write(&mut self, addr: u16, val: u8);
}
```

### Option C: Cycle-Accurate Execution

Restructure CPU to execute one cycle at a time rather than one instruction at a time. This is how Mesen2 achieves perfect accuracy but requires major architectural changes.

---

## Deferred Work

Due to the complexity and architectural implications, the dummy read implementation has been deferred. Current status:

### Completed
- ✅ Root cause analysis
- ✅ Documentation review
- ✅ Opcode table verification
- ✅ RMW dummy write confirmation
- ✅ Initial implementation attempt
- ✅ Regression testing

### Remaining
- ❌ Working dummy read implementation
- ❌ cpu_dummy_reads.nes passing
- ❌ cpu_dummy_writes_ppumem.nes passing
- ❌ cpu_instr_timing tests passing

---

## Recommendations

### For M8 Sprint 3+

1. **Architectural Refactor:** Consider cycle-accurate CPU implementation
2. **Reference Implementation Study:** Examine how TetaNES/Mesen2 handle dummy reads
3. **Incremental Approach:** Fix one addressing mode at a time with targeted tests
4. **Bus Abstraction:** Separate dummy reads from real reads at bus level

### Immediate Next Steps

1. Revert dummy read changes to restore passing tests
2. Focus on other M8 priorities (APU IRQ timing, etc.)
3. Return to dummy reads in a dedicated milestone with proper architecture planning

---

## Lessons Learned

1. **Cycle counting != Bus operations:** Just because cycles are correct doesn't mean bus operations are
2. **Side effects matter:** Dummy reads to PPU/APU registers have observable effects
3. **Test ROM sensitivity:** Blargg tests are very precise about bus-level behavior
4. **Architecture matters:** Some fixes require foundational changes, not just patches

---

**Conclusion:** The dummy read issue is real and well-understood, but fixing it requires more careful architectural consideration than initially anticipated. The current ~50% pass rate on Blargg tests is still a solid baseline. Recommend deferring this work until after other M8 priorities are addressed or until a cycle-accurate CPU refactor is planned.
