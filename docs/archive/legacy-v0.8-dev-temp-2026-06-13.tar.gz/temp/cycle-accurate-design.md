# Cycle-Accurate CPU Emulation - Design Document

**Branch:** `cycle-cycle`
**Status:** Design Phase
**Estimated Effort:** 1-2 weeks
**Complexity:** Very High

## Executive Summary

This document outlines the architectural changes required to transform RustyNES from instruction-level emulation to cycle-accurate emulation. This change is necessary to achieve 100% TASVideos accuracy test pass rate (project goal) and fix timing-related test failures.

## Current vs. Target Architecture

### Current: Instruction-Level Execution
```rust
// Execute entire instruction at once
pub fn step(&mut self, bus: &mut impl Bus) -> u8 {
    let opcode = bus.read(self.pc);  // 1 cycle
    let info = &OPCODE_TABLE[opcode as usize];
    let extra_cycles = self.execute_opcode(opcode, info.addr_mode, bus);
    let total_cycles = info.cycles + extra_cycles;
    self.cycles += u64::from(total_cycles);
    total_cycles  // Returns 2-7 cycles
}
```

**Problem:** Entire instruction executes atomically. PPU/APU synchronization happens after instruction completes.

### Target: Cycle-Accurate Execution
```rust
// Execute ONE cycle at a time
pub fn tick(&mut self, bus: &mut impl Bus) -> bool {
    match self.cpu_state {
        CpuState::FetchOpcode => self.tick_fetch_opcode(bus),
        CpuState::FetchOperandLo => self.tick_fetch_operand_lo(bus),
        CpuState::FetchOperandHi => self.tick_fetch_operand_hi(bus),
        CpuState::Execute => self.tick_execute(bus),
        // ... other states
    }
}
```

**Benefit:** PPU/APU can be synchronized every CPU cycle. Perfect timing accuracy.

---

## Phase 1: CPU Cycle-by-Cycle Execution

### New Data Structures

#### 1. CPU State Machine
```rust
/// CPU execution state
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CpuState {
    /// Fetch opcode from PC
    FetchOpcode,
    /// Fetch low byte of operand
    FetchOperandLo,
    /// Fetch high byte of operand
    FetchOperandHi,
    /// Resolve effective address (may take multiple cycles)
    ResolveAddress,
    /// Read data from effective address
    ReadData,
    /// Write data to effective address
    WriteData,
    /// Read-Modify-Write: Read phase
    RMWRead,
    /// Read-Modify-Write: Dummy write old value
    RMWDummyWrite,
    /// Read-Modify-Write: Write new value
    RMWWrite,
    /// Execute instruction (internal operation, no bus access)
    Execute,
}
```

#### 2. Instruction Type Classification
```rust
/// Instruction execution pattern
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InstructionType {
    /// Read instructions (LDA, LDX, LDY, AND, ORA, EOR, CMP, ADC, SBC, BIT, etc.)
    Read,
    /// Write instructions (STA, STX, STY)
    Write,
    /// Read-Modify-Write (ASL, LSR, ROL, ROR, INC, DEC, DCP, ISC, etc.)
    ReadModifyWrite,
    /// Implied/Register operations (TAX, INX, CLC, NOP, etc.)
    ImpliedRegister,
    /// Branch instructions (BEQ, BNE, BCC, BCS, etc.)
    Branch,
    /// Jump instructions (JMP, JSR)
    Jump,
    /// Return instructions (RTS, RTI)
    Return,
    /// Stack operations (PHA, PLA, PHP, PLP)
    Stack,
    /// Interrupt handling (BRK, NMI, IRQ)
    Interrupt,
}
```

#### 3. Extended Opcode Table
```rust
pub struct OpcodeInfo {
    pub mnemonic: &'static str,
    pub addr_mode: AddressingMode,
    pub instr_type: InstructionType,  // NEW
    pub cycles: u8,
    pub page_cross_penalty: bool,
    pub unofficial: bool,
}
```

#### 4. Extended CPU Struct
```rust
pub struct Cpu {
    // Existing registers
    pub a: u8,
    pub x: u8,
    pub y: u8,
    pub pc: u16,
    pub sp: u8,
    pub status: StatusFlags,
    pub cycles: u64,
    pub stall: u8,
    nmi_pending: bool,
    irq_pending: bool,
    pub jammed: bool,

    // NEW: Cycle-accurate execution state
    cpu_state: CpuState,
    opcode: u8,
    addr_mode: AddressingMode,
    instr_type: InstructionType,
    operand_lo: u8,
    operand_hi: u8,
    effective_addr: u16,
    temp_value: u8,
    base_addr: u16,  // For page crossing detection
}
```

### Implementation Examples

#### Example 1: LDA $1234,X (AbsoluteX, 4-5 cycles)

**No Page Crossing (4 cycles):**
```
Cycle 1: FetchOpcode
    opcode = read(PC);  // $BD
    PC++;
    state = FetchOperandLo;

Cycle 2: FetchOperandLo
    operand_lo = read(PC);  // $34
    PC++;
    state = FetchOperandHi;

Cycle 3: FetchOperandHi
    operand_hi = read(PC);  // $12
    PC++;
    base_addr = (operand_hi << 8) | operand_lo;  // $1234
    effective_addr = base_addr + X;  // $1234 + $10 = $1244
    if page_crossed(base_addr, effective_addr) {
        state = DummyRead;
    } else {
        state = ReadData;
    }

Cycle 4: ReadData
    A = read(effective_addr);  // $1244
    set_zn(A);
    state = FetchOpcode;  // Instruction complete
    return true;
```

**With Page Crossing (5 cycles):**
```
Cycle 1-3: Same as above

Cycle 3 (continued):
    base_addr = $12FF
    effective_addr = $12FF + $01 = $1300
    page_crossed = true
    state = DummyRead;

Cycle 4: DummyRead
    dummy_addr = (base_addr & 0xFF00) | (effective_addr & 0x00FF);  // $12 | $00 = $1200
    _ = read(dummy_addr);  // Read from wrong page
    state = ReadData;

Cycle 5: ReadData
    A = read(effective_addr);  // $1300
    set_zn(A);
    state = FetchOpcode;
    return true;
```

#### Example 2: INC $1234,X (RMW AbsoluteX, 7 cycles)

```
Cycle 1: FetchOpcode
    opcode = read(PC);  // $FE
    PC++;
    state = FetchOperandLo;

Cycle 2: FetchOperandLo
    operand_lo = read(PC);
    PC++;
    state = FetchOperandHi;

Cycle 3: FetchOperandHi
    operand_hi = read(PC);
    PC++;
    base_addr = (operand_hi << 8) | operand_lo;
    effective_addr = base_addr + X;
    // RMW ALWAYS does dummy read
    state = DummyRead;

Cycle 4: DummyRead
    dummy_addr = (base_addr & 0xFF00) | (effective_addr & 0x00FF);
    _ = read(dummy_addr);
    state = RMWRead;

Cycle 5: RMWRead
    temp_value = read(effective_addr);
    state = RMWDummyWrite;

Cycle 6: RMWDummyWrite
    write(effective_addr, temp_value);  // Write old value back
    temp_value = temp_value.wrapping_add(1);
    set_zn(temp_value);
    state = RMWWrite;

Cycle 7: RMWWrite
    write(effective_addr, temp_value);  // Write new value
    state = FetchOpcode;
    return true;
```

### Key Implementation Functions

```rust
impl Cpu {
    /// Execute exactly ONE CPU cycle
    pub fn tick(&mut self, bus: &mut impl Bus) -> bool {
        self.cycles += 1;

        // Handle DMA stalls
        if self.stall > 0 {
            self.stall -= 1;
            return false;
        }

        // Handle CPU jam
        if self.jammed {
            return false;
        }

        // State machine
        match self.cpu_state {
            CpuState::FetchOpcode => self.tick_fetch_opcode(bus),
            CpuState::FetchOperandLo => self.tick_fetch_operand_lo(bus),
            CpuState::FetchOperandHi => self.tick_fetch_operand_hi(bus),
            CpuState::ResolveAddress => self.tick_resolve_address(bus),
            CpuState::ReadData => self.tick_read_data(bus),
            CpuState::WriteData => self.tick_write_data(bus),
            CpuState::RMWRead => self.tick_rmw_read(bus),
            CpuState::RMWDummyWrite => self.tick_rmw_dummy_write(bus),
            CpuState::RMWWrite => self.tick_rmw_write(bus),
            CpuState::Execute => self.tick_execute(bus),
        }
    }

    fn tick_fetch_opcode(&mut self, bus: &mut impl Bus) -> bool {
        // Check for interrupts (NMI/IRQ)
        if self.nmi_pending {
            self.nmi_pending = false;
            self.start_interrupt(bus, InterruptType::NMI);
            return false;
        }

        if self.irq_pending && !self.status.contains(StatusFlags::INTERRUPT_DISABLE) {
            self.start_interrupt(bus, InterruptType::IRQ);
            return false;
        }

        // Fetch opcode
        self.opcode = bus.read(self.pc);
        self.pc = self.pc.wrapping_add(1);

        // Look up opcode info
        let info = &OPCODE_TABLE[self.opcode as usize];
        self.addr_mode = info.addr_mode;
        self.instr_type = info.instr_type;

        // Transition to next state based on addressing mode
        match self.addr_mode {
            AddressingMode::Implied | AddressingMode::Accumulator => {
                self.cpu_state = CpuState::Execute;
            }
            AddressingMode::Immediate => {
                self.cpu_state = CpuState::FetchOperandLo;
            }
            AddressingMode::ZeroPage | AddressingMode::ZeroPageX | AddressingMode::ZeroPageY => {
                self.cpu_state = CpuState::FetchOperandLo;
            }
            _ => {
                self.cpu_state = CpuState::FetchOperandLo;
            }
        }

        false  // Instruction not complete
    }

    fn tick_fetch_operand_lo(&mut self, bus: &mut impl Bus) -> bool {
        self.operand_lo = bus.read(self.pc);
        self.pc = self.pc.wrapping_add(1);

        match self.addr_mode {
            AddressingMode::Immediate => {
                // Immediate: operand_lo is the value
                self.cpu_state = CpuState::Execute;
            }
            AddressingMode::ZeroPage => {
                // Zero page: operand_lo is the address
                self.effective_addr = self.operand_lo as u16;
                self.transition_after_address_resolved();
            }
            AddressingMode::ZeroPageX | AddressingMode::ZeroPageY => {
                // Need internal cycle to add index
                self.cpu_state = CpuState::ResolveAddress;
            }
            _ => {
                // Multi-byte addressing modes need high byte
                self.cpu_state = CpuState::FetchOperandHi;
            }
        }

        false
    }

    fn tick_fetch_operand_hi(&mut self, bus: &mut impl Bus) -> bool {
        self.operand_hi = bus.read(self.pc);
        self.pc = self.pc.wrapping_add(1);

        self.base_addr = u16::from_le_bytes([self.operand_lo, self.operand_hi]);

        match self.addr_mode {
            AddressingMode::Absolute => {
                self.effective_addr = self.base_addr;
                self.transition_after_address_resolved();
            }
            AddressingMode::AbsoluteX | AddressingMode::AbsoluteY => {
                let index = match self.addr_mode {
                    AddressingMode::AbsoluteX => self.x,
                    AddressingMode::AbsoluteY => self.y,
                    _ => unreachable!(),
                };

                self.effective_addr = self.base_addr.wrapping_add(index as u16);

                // Check if we need dummy read
                let page_crossed = (self.base_addr & 0xFF00) != (self.effective_addr & 0xFF00);

                match self.instr_type {
                    InstructionType::Read => {
                        if page_crossed {
                            self.cpu_state = CpuState::ResolveAddress;  // Dummy read
                        } else {
                            self.cpu_state = CpuState::ReadData;
                        }
                    }
                    InstructionType::Write | InstructionType::ReadModifyWrite => {
                        // Always dummy read for writes/RMW
                        self.cpu_state = CpuState::ResolveAddress;
                    }
                    _ => unreachable!(),
                }
            }
            _ => todo!("Handle other addressing modes"),
        }

        false
    }

    fn tick_resolve_address(&mut self, bus: &mut impl Bus) -> bool {
        // Dummy read from wrong page
        let dummy_addr = (self.base_addr & 0xFF00) | (self.effective_addr & 0x00FF);
        let _ = bus.read(dummy_addr);

        self.transition_after_address_resolved();
        false
    }

    fn tick_read_data(&mut self, bus: &mut impl Bus) -> bool {
        let value = bus.read(self.effective_addr);

        // Execute the actual instruction operation
        match self.opcode {
            0xA9 | 0xA5 | 0xB5 | 0xAD | 0xBD | 0xB9 | 0xA1 | 0xB1 => {
                // LDA
                self.a = value;
                self.set_zn(value);
            }
            0xA2 | 0xA6 | 0xB6 | 0xAE | 0xBE => {
                // LDX
                self.x = value;
                self.set_zn(value);
            }
            0xA0 | 0xA4 | 0xB4 | 0xAC | 0xBC => {
                // LDY
                self.y = value;
                self.set_zn(value);
            }
            // ... more read instructions
            _ => todo!("Implement all read instructions"),
        }

        self.cpu_state = CpuState::FetchOpcode;
        true  // Instruction complete
    }

    fn transition_after_address_resolved(&mut self) {
        match self.instr_type {
            InstructionType::Read => {
                self.cpu_state = CpuState::ReadData;
            }
            InstructionType::Write => {
                self.cpu_state = CpuState::WriteData;
            }
            InstructionType::ReadModifyWrite => {
                self.cpu_state = CpuState::RMWRead;
            }
            _ => unreachable!(),
        }
    }
}
```

---

## Phase 2: PPU Dot-by-Dot Execution

### Current PPU
```rust
pub fn step(&mut self, cycles: u16, bus: &mut PpuBus) {
    for _ in 0..cycles {
        // Execute 3 PPU dots per CPU cycle
        self.tick(bus);
        self.tick(bus);
        self.tick(bus);
    }
}
```

### Target PPU
```rust
pub fn tick(&mut self, bus: &mut PpuBus) {
    match (self.scanline, self.dot) {
        // Pre-render scanline (261)
        (261, 1) => self.clear_vblank_flag(),
        (261, 280..=304) if self.rendering_enabled() => self.copy_vertical_bits(),

        // Visible scanlines (0-239)
        (0..=239, 1..=256) => self.render_pixel(bus),
        (0..=239, 257) => self.copy_horizontal_bits(),
        (0..=239, 321..=336) => self.fetch_next_scanline_data(bus),

        // Post-render scanline (240) - idle
        (240, _) => {}

        // VBlank scanlines (241-260)
        (241, 1) => self.set_vblank_and_trigger_nmi(),

        _ => {}
    }

    self.advance_dot();
}

fn advance_dot(&mut self) {
    self.dot += 1;
    if self.dot > 340 {
        self.dot = 0;
        self.scanline += 1;
        if self.scanline > 261 {
            self.scanline = 0;
            self.frame += 1;
            self.odd_frame = !self.odd_frame;
        }
    }
}
```

---

## Phase 3: Master Clock Integration

```rust
impl Console {
    /// Execute one CPU cycle with synchronized PPU/APU
    ///
    /// NTSC timing:
    /// - Master clock: 21.477272 MHz
    /// - CPU: Master / 12 = 1.789773 MHz
    /// - PPU: Master / 4 = 5.369318 MHz (3 dots per CPU cycle)
    pub fn tick(&mut self) {
        // CPU executes one cycle
        let instruction_complete = self.cpu.tick(&mut self.bus);

        // PPU executes 3 dots (3x PPU clock per CPU clock)
        for _ in 0..3 {
            self.ppu.tick(&mut self.ppu_bus);

            // Check for NMI
            if self.ppu.nmi_pending() {
                self.cpu.trigger_nmi();
                self.ppu.clear_nmi_pending();
            }
        }

        // APU executes one cycle (same as CPU clock)
        self.apu.tick();

        // Check for APU IRQ
        if self.apu.irq_pending() {
            self.cpu.set_irq(true);
        } else {
            self.cpu.set_irq(false);
        }

        // Handle DMA if active
        if self.dma_active {
            self.execute_dma_cycle();
        }
    }

    /// Run for one frame (29780.5 CPU cycles NTSC)
    pub fn run_frame(&mut self) {
        const CYCLES_PER_FRAME: u32 = 29_781;

        for _ in 0..CYCLES_PER_FRAME {
            self.tick();
        }
    }
}
```

---

## Phase 4: OAM DMA Cycle Accuracy

```rust
impl Bus {
    pub fn handle_oam_dma(&mut self, cpu: &mut Cpu, ppu: &mut Ppu, apu: &mut Apu, page: u8) {
        // DMA takes 513 or 514 cycles depending on CPU cycle parity
        let extra_cycle = if cpu.cycles % 2 == 1 { 1 } else { 0 };

        // Idle cycle(s)
        for _ in 0..=extra_cycle {
            cpu.tick_idle(self);
            ppu.tick(); ppu.tick(); ppu.tick();  // 3 PPU dots
            apu.tick();
        }

        // 256 byte transfer (2 cycles each: read + write)
        for i in 0..256u16 {
            let addr = (page as u16) << 8 | i;

            // Read cycle
            let data = self.read(addr);
            ppu.tick(); ppu.tick(); ppu.tick();
            apu.tick();

            // Write cycle
            ppu.oam_data_write(data);
            ppu.tick(); ppu.tick(); ppu.tick();
            apu.tick();
        }

        cpu.cycles += 513 + extra_cycle as u64;
    }
}
```

---

## Implementation Roadmap

### Week 1: CPU Foundation
- **Day 1-2:** Implement state machine enums and extend CPU struct
- **Day 3-4:** Implement addressing mode cycle handlers
- **Day 5:** Implement Read instruction type (LDA, LDX, LDY, etc.)
- **Day 6:** Implement Write instruction type (STA, STX, STY)
- **Day 7:** Unit tests for basic instructions

### Week 2: Complete CPU + PPU Integration
- **Day 1-2:** Implement RMW instruction type
- **Day 3:** Implement Branch/Jump/Stack/Interrupt types
- **Day 4:** PPU dot-by-dot execution
- **Day 5:** Master clock integration
- **Day 6:** DMA cycle accuracy
- **Day 7:** Full integration testing

---

## Testing Strategy

### Unit Tests
```rust
#[test]
fn test_lda_absolute_x_no_page_cross() {
    let mut cpu = Cpu::new();
    let mut bus = TestBus::new();

    // Set up: LDA $1200,X with X=$10
    bus.write(0x8000, 0xBD);  // LDA absolute,X
    bus.write(0x8001, 0x00);
    bus.write(0x8002, 0x12);
    bus.write(0x1210, 0x42);  // Target value

    cpu.pc = 0x8000;
    cpu.x = 0x10;

    // Cycle 1: Fetch opcode
    assert!(!cpu.tick(&mut bus));
    assert_eq!(cpu.pc, 0x8001);
    assert_eq!(cpu.opcode, 0xBD);

    // Cycle 2: Fetch low byte
    assert!(!cpu.tick(&mut bus));
    assert_eq!(cpu.pc, 0x8002);
    assert_eq!(cpu.operand_lo, 0x00);

    // Cycle 3: Fetch high byte
    assert!(!cpu.tick(&mut bus));
    assert_eq!(cpu.pc, 0x8003);
    assert_eq!(cpu.effective_addr, 0x1210);

    // Cycle 4: Read data (no page cross, no dummy read)
    assert!(cpu.tick(&mut bus));  // Instruction complete
    assert_eq!(cpu.a, 0x42);
    assert_eq!(cpu.cycles, 4);
}

#[test]
fn test_lda_absolute_x_page_cross() {
    let mut cpu = Cpu::new();
    let mut bus = TestBus::new();

    // Set up: LDA $12FF,X with X=$01 (crosses to $1300)
    bus.write(0x8000, 0xBD);
    bus.write(0x8001, 0xFF);
    bus.write(0x8002, 0x12);
    bus.write(0x1300, 0x42);

    cpu.pc = 0x8000;
    cpu.x = 0x01;

    // Cycles 1-3: Same as above
    cpu.tick(&mut bus);
    cpu.tick(&mut bus);
    cpu.tick(&mut bus);

    // Cycle 4: Dummy read from $12FF (wrong page)
    assert!(!cpu.tick(&mut bus));

    // Cycle 5: Read data from $1300 (correct page)
    assert!(cpu.tick(&mut bus));
    assert_eq!(cpu.a, 0x42);
    assert_eq!(cpu.cycles, 5);
}
```

### Integration Tests
- Run nestest.nes with cycle-accurate timing
- Verify CPU/PPU synchronization with ppu_vbl_nmi tests
- Verify DMA timing with cpu_dummy_reads/writes tests
- Verify interrupt timing with cpu_interrupts tests

---

## Expected Test Results

| Test | Current | Target | Notes |
|------|---------|--------|-------|
| Library Tests | 361/361 | 361/361 | Should maintain 100% |
| nestest.nes | Pass | Pass | Cycle counts must match golden log |
| cpu_dummy_reads.nes | Fail | Pass | Fixed by cycle-accurate dummy reads |
| cpu_dummy_writes_ppumem.nes | Fail | Pass | Fixed by PPU register timing |
| cpu_instr_timing.nes | Fail | Pass | Fixed by perfect cycle accuracy |
| cpu_interrupts.nes | Fail | Pass | Fixed by interrupt poll timing |
| CPU Test Pass Rate | 10/21 (47.6%) | 20/21+ (95%+) | Gold standard accuracy |

---

## Performance Considerations

### Current Performance
- Instruction-level: ~1.8 MHz emulated speed
- Desktop GUI runs at 60 FPS easily

### Expected Performance Impact
- Cycle-accurate: 10-30% slower (more function calls, state management)
- Still target 60 FPS on modern hardware
- Optimization opportunities:
  - Inline tick() methods
  - Minimize state transitions
  - Profile hot paths

### Mitigation Strategies
1. Use `#[inline(always)]` for tick methods
2. Minimize heap allocations
3. Profile with `cargo flamegraph`
4. Consider fast-path for simple instructions
5. Optional "turbo mode" that skips PPU rendering

---

## Risk Assessment

### High Risk
- **Complexity:** 2000+ lines of new code
- **Regressions:** Easy to break existing functionality
- **Testing:** Need exhaustive test coverage
- **Time:** 1-2 weeks full-time effort

### Mitigation
- Incremental implementation (one phase at a time)
- Comprehensive unit tests at each step
- Keep main branch stable, work on feature branch
- Regular validation against nestest.nes

---

## Alternatives Considered

### Option A: Continue with Instruction-Level + Fixes
- **Pros:** Less work, simpler code
- **Cons:** Will never achieve 100% accuracy, timing bugs persist

### Option B: Hybrid Approach
- **Pros:** Balance accuracy and simplicity
- **Cons:** Complex to maintain two execution paths

### Option C: Full Cycle-Accurate (THIS DOCUMENT)
- **Pros:** Perfect accuracy, clean architecture, TAS-ready
- **Cons:** High complexity, performance cost

**Recommendation:** Option C is aligned with project goals (100% TASVideos accuracy).

---

## Next Steps

1. **Review this design document**
2. **Approve implementation plan**
3. **Begin Phase 1: CPU cycle-by-cycle**
4. **Iterative development with continuous testing**
5. **Code review at each phase**
6. **Merge when all tests pass**

---

## References

- NESdev Wiki: CPU Timing (https://www.nesdev.org/wiki/CPU_timing)
- Visual6502: Cycle-by-cycle simulation
- Mesen2: Reference cycle-accurate implementation (C++)
- TetaNES: Rust cycle-accurate PPU implementation
- nestest.nes: CPU validation test ROM

---

**Author:** Claude (AI Assistant)
**Date:** 2025-12-20
**Status:** Awaiting approval to proceed with implementation
