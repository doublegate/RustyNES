# RustyNES /tmp/ Recovery Summary

**Date:** December 30, 2025
**Purpose:** Recover project-related files from /tmp/ before system restart

---

## Files Recovered

### 1. Analysis Documents (temp/analysis/)

| File | Description | Date |
|------|-------------|------|
| `analysis.txt` | PPU nametable address calculation analysis | Dec 29 |
| `rustynes_graphical_issues_analysis.md` | Comprehensive PPU graphical issues research report (409 lines) | Dec 29 |
| `fetch_analysis.txt` | Tile fetch cycle timing comparison (RustyNES vs TetaNES) | Dec 28 |

### 2. Test Output (temp/test-output/)

| File | Description | Date |
|------|-------------|------|
| `test-results.txt` | Full test suite results (520+ tests, all passing) | Dec 27 |
| `ignored-tests.txt` | Ignored test information | Dec 28 |
| `test-output.txt` | Additional test execution output | Dec 28 |

### 3. Test Scripts (temp/test-scripts/)

| File | Description | Date |
|------|-------------|------|
| `check_opcode.rs` | ROM opcode verification utility | Dec 26 |
| `test_step_vs_tick.rs` | Compare step() vs tick() mode execution | Dec 26 |
| `nmi_brk_test.rs` | NMI/BRK interrupt test for cpu_interrupts | Dec 27 |
| `irq_debug.rs` | APU IRQ frame counter debug test | Dec 20 |
| `irq_test.rs` | IRQ testing script | Dec 20 |
| `smb_validation.rs` | Super Mario Bros validation test (graphics + audio) | Dec 26 |
| `test_framebuffer.rs` | Framebuffer population verification | Dec 25 |
| `frame_timing_test.rs` | Frame timing verification | Dec 27 |
| `test_frame_len.rs` | Frame length testing | Dec 27 |
| `test_frame_timing.rs` | Frame timing test | Dec 27 |
| `debug_cpu_test.rs` | CPU debugging utility | Dec 26 |
| `rts_test.rs` | RTS instruction comparison (step vs tick) | Dec 26 |

### 4. Debug Tool Projects (temp/debug-tools/)

| Project | Files | Description |
|---------|-------|-------------|
| `smb_framebuffer_compare/` | Cargo.toml, main.rs | Compare framebuffer output between step() and tick() modes |
| `smb_branch_debug/` | Cargo.toml, main.rs | Branch instruction cycle trace comparing step vs tick |
| `smb_nmi_divergence/` | main.rs | Trace cycle drift and NMI divergence between execution modes |
| `smb_nmi_trace/` | main.rs | Trace specific instruction around divergence point 29037 |
| `smb_extended_test/` | main.rs | Investigate divergence at instruction 66891 |
| `smb_test/` | main.rs | Compare when pixels first appear in both modes |
| `rts_comparison/` | main.rs | Compare JSR/RTS behavior between step and tick |
| `check_opcode` | binary | Compiled opcode checker (3.9MB) |

### 5. Test ROM Archives (temp/test-roms-archives/)

| File | Size | Description |
|------|------|-------------|
| `blargg_cpu.zip` | 297KB | Blargg CPU test ROMs archive |

---

## Key Findings from Analysis Files

### rustynes_graphical_issues_analysis.md (Critical)

**Critical Finding #1:** Missing PPUADDR Write Delay Mechanism
- RustyNES immediately copies `t` to `v` on second $2006 write
- TetaNES delays update by 2 PPU cycles
- Affects: Super Mario Bros (palette issues), Excitebike (tile corruption)

**Critical Finding #2:** No cycle-accurate delayed PPUADDR update in PPU step loop
- No `delayed_update()` call in PPU step cycle
- Required for precise timing-dependent games

### fetch_analysis.txt

- Compares tile fetch cycle timing between RustyNES and TetaNES
- Documents fetch pattern order differences
- Both use equivalent % 8 / & 0x07 patterns

---

## Statistics

- **Total files recovered:** 27 new files + preserved 36 existing = 63 total in temp/
- **Total size:** 4.5MB
- **Debug projects:** 7 complete Rust projects with source
- **Test scripts:** 12 standalone Rust test files
- **Analysis documents:** 3 comprehensive reports

---

## Files NOT Recovered (Intentionally Skipped)

- Claude working directory markers (`/tmp/claude-*-cwd`) - ephemeral, not valuable
- Rust compiler temp files (`/tmp/rustdoctest*`, `/tmp/proc-macro-srv*`) - regenerated automatically
- Steam/other application temp files - not project related
- Build cache directories - can be regenerated with `cargo build`

---

## Usage Notes

### Debug Tool Projects

To run a debug tool project:
```bash
cd temp/debug-tools/smb_framebuffer_compare
# Create src/ directory if needed
mkdir -p src && mv main.rs src/
cargo run
```

### Test Scripts

To run a standalone test script:
```bash
cd /home/parobek/Code/RustyNES
rustc temp/test-scripts/smb_validation.rs -o /tmp/smb_validation && /tmp/smb_validation
# Or use cargo script/runner if installed
```

---

## Previously Recovered Files (Already in temp/)

The temp/ directory already contained 36 files from previous recovery/analysis sessions:
- M7/M8 sprint reports and analysis
- CPU dummy reads investigation
- VBlank timing investigation
- Debug scripts and patches
- Release notes and status reports

These were preserved and remain accessible.
