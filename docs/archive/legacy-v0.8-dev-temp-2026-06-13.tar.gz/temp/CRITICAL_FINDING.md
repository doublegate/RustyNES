# CRITICAL FINDING: cpu_dummy_reads.nes Not Executing

**Date:** December 20, 2025
**Discovery:** Root cause of 0xFF status identified

---

## The Smoking Gun

### PRG-RAM Initialization
**File:** `/home/parobek/Code/RustyNES/crates/rustynes-core/src/bus.rs:90`

```rust
prg_ram: [0xFF; 0x2000], // Initialize PRG-RAM to 0xFF (test ROMs expect this)
```

### Blargg Test Status Protocol

**Status Location:** `$6000`
**Values:**
- `0x80` = Test running
- `0x00` = Test passed
- `0x01-0x7F` = Test failed with code
- `0x81` = Reset needed
- **`0xFF` = UNINITIALIZED (never written to)**

### Our Test Result

**Observed:** Status = `0xFF` at frame 11
**Conclusion:** The test ROM **NEVER WROTE TO $6000**

This means:
1. ❌ The test framework initialization DID NOT RUN
2. ❌ The `run_main` routine WAS NOT CALLED
3. ❌ The `main` test function NEVER STARTED
4. ❌ $6000 remains at its power-on value of 0xFF

---

## What This Means

### Our Dummy Read Implementation: ✅ PROBABLY CORRECT

The test is failing BEFORE it even checks dummy reads. The failure has **NOTHING to do with our dummy read implementation**.

### Real Problem: Test ROM Execution

Possible causes:
1. **Reset vector not pointing to correct address**
2. **ROM loading issue**
3. **Mapper initialization problem**
4. **Stack corruption**
5. **CPU not reaching test code**

---

## Verification Steps

### Step 1: Check if ROM Executes at All

Add logging to see if RESET vector is being called:
```rust
// In Console::new() or CPU reset
eprintln!("CPU PC after reset: 0x{:04X}", cpu.pc);
```

### Step 2: Check First Few Instructions

Log first 10-20 instructions executed to see if we reach `run_main`.

### Step 3: Check $6000 Writes

Add logging to bus.rs:
```rust
fn write(&mut self, addr: u16, value: u8) {
    if addr == 0x6000 {
        eprintln!("WRITE $6000 = 0x{:02X}", value);
    }
    // ... rest of write logic
}
```

If we NEVER see a write to $6000, the test framework isn't running.

---

## Next Actions

### Priority 1: Debug ROM Execution
1. Verify RESET vector points to correct address
2. Log first instructions executed
3. Check if we reach shell.inc initialization code
4. Verify stack pointer initialization

### Priority 2: Check Other Failing Tests
Run `cpu_instr_01_implied.nes` (which PASSES) and `cpu_dummy_reads.nes` (which FAILS) with identical logging to compare execution paths.

### Priority 3: ROM Format Validation
Verify cpu_dummy_reads.nes header:
- iNES format correct?
- Mapper correct?
- PRG-ROM size correct?

---

## Hypothesis

**Most Likely:** cpu_dummy_reads.nes uses a different mapper or ROM configuration than the passing tests, and our emulator isn't handling it correctly.

**Alternative:** There's a subtle CPU bug that causes the test framework initialization to crash/hang before reaching main.

---

## Why Dummy Reads Are Not The Problem

If dummy reads were the issue, we would see:
1. ✅ Status = 0x80 (test running)
2. ✅ Then status = 0x02 or higher (specific test failure)
3. ✅ Error message in $6004+

Instead we see:
1. ❌ Status = 0xFF (never initialized)
2. ❌ No error message
3. ❌ Test framework never ran

**Conclusion:** The test isn't even getting to the point where it checks dummy reads.

---

## Recommended Immediate Action

**Run this test:**
```bash
cargo test cpu_dummy_reads --release -- --nocapture 2>&1 | grep -E "PC|WRITE|6000"
```

With added debug logging to see:
- Initial PC value
- First 20 instructions executed
- Any writes to $6000

This will tell us if the ROM is executing at all.
