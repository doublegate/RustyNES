use rustynes_core::Console;
use std::path::PathBuf;

fn main() {
    let rom_path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("..") // crates/
        .join("..") // workspace root
        .join("test-roms")
        .join("cpu")
        .join("cpu_instr_06_abs_xy.nes");

    if !rom_path.exists() {
        eprintln!("ROM not found at {}", rom_path.display());
        return;
    }

    let rom_data = std::fs::read(&rom_path).unwrap();
    let mut console = Console::from_rom_bytes(&rom_data).unwrap();

    println!("Running cpu_instr_06_abs_xy.nes with debug output...");

    for frame in 0..100 {
        console.step_frame();

        let status = console.peek_memory(0x6000);

        if frame % 10 == 0 {
            println!("Frame {}: status=$6000={:02X}", frame, status);
        }

        // Check completion
        match status {
            0x80 => continue, // Still running
            0x81 => {
                println!("Frame {}: Test requested reset", frame);
                break;
            }
            0x00 => {
                println!("Frame {}: PASS", frame);
                return;
            }
            _ => {
                // Fail - try to read error text
                let mut error_text = String::new();
                for i in 0..256 {
                    let ch = console.peek_memory(0x6004 + i);
                    if ch == 0 {
                        break;
                    }
                    if ch.is_ascii() && ch >= 0x20 {
                        error_text.push(ch as char);
                    }
                }
                println!("Frame {}: FAIL status={:02X}", frame, status);
                if !error_text.is_empty() {
                    println!("  Error: {}", error_text);
                }
                break;
            }
        }
    }

    println!("Test did not complete in 100 frames");
}
