// Measure exact frame length in PPU dots

fn main() {
    use rustynes_core::Console;
    
    // Create minimal ROM
    let mut rom = vec![0; 16 + 16384 + 8192];
    rom[0..4].copy_from_slice(&[0x4E, 0x45, 0x53, 0x1A]);
    rom[4] = 1; // 1 PRG bank
    rom[5] = 1; // 1 CHR bank
    rom[16 + 0x7FFC] = 0x00; // Reset vector low
    rom[16 + 0x7FFD] = 0x80; // Reset vector high
    rom[16] = 0xEA; // NOP at $8000
    rom[17] = 0x4C; // JMP $8000
    rom[18] = 0x00;
    rom[19] = 0x80;
    
    let mut console = Console::from_rom_bytes(&rom).unwrap();
    
    // Run a few frames to stabilize, then measure
    for _ in 0..5 {
        console.step_frame_accurate();
    }
    
    // Measure exact tick counts for 10 frames
    for frame in 0..10 {
        let start_frame = console.frame_count();
        let mut ticks = 0u64;
        
        while console.frame_count() == start_frame {
            console.tick();
            ticks += 1;
        }
        
        // Each tick = 1 CPU cycle = 3 PPU dots
        let ppu_dots = ticks * 3;
        let expected = if (start_frame % 2) == 1 && false { 
            89341  // Odd frame with skip (but rendering disabled, so no skip)
        } else {
            89342  // Normal frame
        };
        
        println!("Frame {}: {} ticks ({} PPU dots, expected {})", 
                 frame, ticks, ppu_dots, expected);
    }
}
