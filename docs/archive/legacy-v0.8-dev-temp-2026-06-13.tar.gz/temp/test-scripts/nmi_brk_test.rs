// Quick test to compare step() vs tick() behavior for cpu_interrupts test
use rustynes_core::Console;

fn run_test_with_step() -> String {
    let rom_path = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("test-roms")
        .join("cpu")
        .join("cpu_interrupts.nes");
    
    let rom_data = std::fs::read(&rom_path).unwrap();
    let mut console = Console::from_rom_bytes(&rom_data).unwrap();
    
    // Run for 170 frames using step_frame (instruction-based)
    for _ in 0..170 {
        console.step_frame();
    }
    
    // Read test output from $6004
    let mut msg = String::new();
    for i in 0..256u16 {
        let ch = console.peek_memory(0x6004 + i);
        if ch == 0 { break; }
        if ch.is_ascii() && ch >= 0x20 {
            msg.push(ch as char);
        }
    }
    msg
}

fn run_test_with_tick() -> String {
    let rom_path = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("test-roms")
        .join("cpu")
        .join("cpu_interrupts.nes");
    
    let rom_data = std::fs::read(&rom_path).unwrap();
    let mut console = Console::from_rom_bytes(&rom_data).unwrap();
    
    // Run for 170 frames using step_frame_accurate (cycle-based)
    for _ in 0..170 {
        console.step_frame_accurate();
    }
    
    // Read test output from $6004
    let mut msg = String::new();
    for i in 0..256u16 {
        let ch = console.peek_memory(0x6004 + i);
        if ch == 0 { break; }
        if ch.is_ascii() && ch >= 0x20 {
            msg.push(ch as char);
        }
    }
    msg
}

fn main() {
    println!("=== step_frame (instruction-based) ===");
    println!("{}", run_test_with_step());
    println!();
    println!("=== step_frame_accurate (cycle-based) ===");
    println!("{}", run_test_with_tick());
}
