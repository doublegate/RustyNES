// Quick IRQ propagation test
use rustynes_apu::frame_counter::FrameCounter;

fn main() {
    let mut fc = FrameCounter::new();
    
    // Write $00 to $4017 (4-step mode, IRQ enabled)
    fc.write_control(0x00);
    println!("After write_control(0x00): irq_pending={}", fc.irq_pending());
    
    // Clock until IRQ should fire (cycle 29829)
    for i in 0..29829 {
        fc.clock();
        if fc.irq_pending() {
            println!("IRQ pending at cycle {}", i + 1);
            break;
        }
    }
    
    if !fc.irq_pending() {
        // Clock a few more to check
        for i in 29829..29835 {
            fc.clock();
            println!("Cycle {}: irq_flag={}, irq_pending={}", i + 1, fc.irq_flag, fc.irq_pending());
        }
    }
}
