// Quick debug script to trace CPU test ROM execution
use rustynes_core::Console;

fn main() {
    let rom_data = std::fs::read("test-roms/cpu/cpu_instr_01_implied.nes").unwrap();
    let mut console = Console::from_rom_bytes(&rom_data).unwrap();

    println!("Initial PC: {:04X}", console.cpu().pc);
    println!("Initial status at $6000: {:02X}", console.peek_memory(0x6000));

    // Run some initial instructions to see what's happening
    for i in 0..100 {
        let cycles = console.step();
        let pc = console.cpu().pc;
        let status = console.peek_memory(0x6000);

        if i < 20 || status != 0x00 {
            println!("Step {}: PC={:04X}, cycles={}, $6000={:02X}", i, pc, cycles, status);
        }

        if status == 0x80 {
            println!("Test ROM initialized (status=0x80 running)");
            break;
        }
    }

    println!("\n--- Running frames ---");

    // Run for 100 frames
    for frame in 0..100 {
        console.step_frame_accurate();

        let status = console.peek_memory(0x6000);
        let total_cycles = console.cycles();

        if frame % 10 == 0 || status != 0x80 {
            println!("Frame {}: status=${:02X}, cycles={}", frame, status, total_cycles);

            if status == 0x00 {
                println!("PASS!");
                return;
            } else if status != 0x80 && status != 0x00 {
                // Read error message
                let mut msg = String::new();
                for i in 0..256u16 {
                    let ch = console.peek_memory(0x6004 + i);
                    if ch == 0 { break; }
                    if ch.is_ascii() && ch >= 0x20 {
                        msg.push(ch as char);
                    }
                }
                println!("Error (status={:02X}): {}", status, msg);
                return;
            }
        }
    }

    // Check final state
    let status = console.peek_memory(0x6000);
    println!("\nFinal status: ${:02X}", status);
    println!("Final PC: {:04X}", console.cpu().pc);

    // Read any message
    let mut msg = String::new();
    for i in 0..256u16 {
        let ch = console.peek_memory(0x6004 + i);
        if ch == 0 { break; }
        if ch.is_ascii() && ch >= 0x20 {
            msg.push(ch as char);
        }
    }
    if !msg.is_empty() {
        println!("Message at $6004: {}", msg);
    }

    println!("Timeout after 100 frames");
}
