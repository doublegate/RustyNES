// Test frame timing accuracy
use rustynes_core::Console;

fn main() {
    // Create a minimal ROM with just header (16 bytes) + 16KB PRG + 8KB CHR
    let mut rom = vec![0; 16 + 16384 + 8192];
    rom[0..4].copy_from_slice(&[0x4E, 0x45, 0x53, 0x1A]); // NES header
    rom[4] = 1; // 1 PRG bank
    rom[5] = 1; // 1 CHR bank
    
    // Simple program: infinite loop
    rom[16 + 0x7FFC] = 0x00; // Reset vector low
    rom[16 + 0x7FFD] = 0x80; // Reset vector high
    rom[16] = 0x4C;          // JMP $8000
    rom[17] = 0x00;
    rom[18] = 0x80;
    
    let mut console = Console::from_rom_bytes(&rom).unwrap();
    
    // Run 10 frames using tick() and count PPU dots
    let mut total_dots: u64 = 0;
    for frame_num in 0..10 {
        let start_frame = console.frame_count();
        let mut dots_this_frame = 0u64;
        
        while console.frame_count() == start_frame {
            console.tick();
            dots_this_frame += 3; // 3 PPU dots per tick
        }
        
        total_dots += dots_this_frame;
        println!("Frame {}: {} PPU dots ({} CPU cycles)", 
                 frame_num, dots_this_frame, dots_this_frame / 3);
    }
    
    let avg_dots = total_dots / 10;
    let avg_cycles = total_dots / 30;
    println!();
    println!("Average: {} PPU dots per frame ({} CPU cycles)", avg_dots, avg_cycles);
    println!("Expected: 89342 dots (even frame) or 89341 (odd frame)");
    println!("Expected average with rendering disabled: 89342 dots");
}
