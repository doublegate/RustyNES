// Test to compare step() vs tick() behavior
use rustynes_core::Console;

fn run_test_with_step(path: &str) -> Option<u8> {
    let rom_data = std::fs::read(path).ok()?;
    let mut console = Console::from_rom_bytes(&rom_data).ok()?;
    
    // Run for 1200 frames using step_frame (uses step() internally)
    for frame in 0..1200 {
        console.step_frame();
        
        if frame >= 10 {
            let status = console.peek_memory(0x6000);
            if status != 0x80 {
                println!("step_frame: status={:02X} at frame {}", status, frame);
                return Some(status);
            }
        }
    }
    
    println!("step_frame: timeout (status={:02X})", console.peek_memory(0x6000));
    None
}

fn run_test_with_tick(path: &str) -> Option<u8> {
    let rom_data = std::fs::read(path).ok()?;
    let mut console = Console::from_rom_bytes(&rom_data).ok()?;
    
    // Run for 1200 frames using step_frame_accurate (uses tick() internally)
    for frame in 0..1200 {
        console.step_frame_accurate();
        
        if frame >= 10 {
            let status = console.peek_memory(0x6000);
            if status != 0x80 {
                println!("step_frame_accurate: status={:02X} at frame {}", status, frame);
                return Some(status);
            }
        }
    }
    
    println!("step_frame_accurate: timeout (status={:02X})", console.peek_memory(0x6000));
    None
}

fn main() {
    let cpu_rom = "test-roms/cpu/cpu_instr_01_implied.nes";
    let apu_rom = "test-roms/apu/apu_len_timing.nes";
    
    println!("=== Testing CPU ROM ===");
    println!("Using step_frame (instruction-based):");
    run_test_with_step(cpu_rom);
    println!("\nUsing step_frame_accurate (cycle-based):");
    run_test_with_tick(cpu_rom);
    
    println!("\n=== Testing APU ROM ===");
    println!("Using step_frame (instruction-based):");
    run_test_with_step(apu_rom);
    println!("\nUsing step_frame_accurate (cycle-based):");
    run_test_with_tick(apu_rom);
}
