// Quick APU IRQ debug test
// Run with: cargo test --test irq_debug -- --nocapture

use rustynes_apu::Apu;

fn main() {
    let mut apu = Apu::new();

    // Write $00 to $4017 (4-step mode, IRQ enabled)
    println!("Writing $00 to $4017 (4-step mode, IRQ enabled)");
    apu.write_register(0x4017, 0x00);

    // Check initial state
    let status = apu.read_register(0x4015);
    println!("Initial $4015 status: 0x{:02X} (bit 6 = {})", status, (status & 0x40) != 0);

    // Clock until cycle 29829
    println!("\nClocking APU for 29829 cycles...");
    for cycle in 1..=29835 {
        apu.step();

        // Check IRQ at key cycles
        if cycle >= 29827 && cycle <= 29835 {
            let status = apu.read_register(0x4015);
            let irq_pending = apu.irq_pending();
            // Note: reading $4015 clears the IRQ flag, so we need to write $4017 again
            // Actually, let's not read $4015 - just check irq_pending()
            println!("Cycle {}: irq_pending = {}", cycle, irq_pending);
        }
    }

    // Check final state
    let status = apu.read_register(0x4015);
    println!("\nFinal $4015 status: 0x{:02X} (bit 6 = {})", status, (status & 0x40) != 0);
    println!("APU irq_pending(): {}", apu.irq_pending());
}
