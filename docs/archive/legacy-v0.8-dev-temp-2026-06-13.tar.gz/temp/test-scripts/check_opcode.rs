use std::fs;

fn main() {
    let smb_path = "/home/parobek/Code/RustyNES/game-roms/Super Mario Bros.nes";
    let rom_data = fs::read(smb_path).expect("Failed to read ROM");
    
    // Check several addresses that are showing drift
    let addresses = [0x8181, 0x8057, 0x8082];
    
    for addr in addresses {
        let prg_offset = addr - 0x8000;
        let file_offset = 16 + prg_offset;
        let opcode = rom_data[file_offset];
        let op1 = rom_data[file_offset + 1];
        let op2 = rom_data[file_offset + 2];
        
        println!("Address 0x{:04X}: opcode=0x{:02X}, operands=0x{:02X} 0x{:02X}", 
                 addr, opcode, op1, op2);
    }
}
