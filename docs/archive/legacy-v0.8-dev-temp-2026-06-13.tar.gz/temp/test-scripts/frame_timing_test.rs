// Test frame timing accuracy
use rustynes_core::Console;

fn main() {
    // Create a minimal ROM with just header (16 bytes) + 16KB PRG + 8KB CHR
    let mut rom = vec![0; 16 + 16384 + 8192];
    rom[0..4].copy_from_slice(&[0x4E, 0x45, 0x53, 0x1A]); // NES header
    rom[4] = 1; // 1 PRG bank
    rom[5] = 1; // 1 CHR bank
    
    // Simple program: infinite loop at $8000
    // Reset vector points to $8000
    rom[16 + 0x7FFC] = 0x00; // Reset vector low
    rom[16 + 0x7FFD] = 0x80; // Reset vector high
    rom[16] = 0x4C;          // JMP $8000
    rom[17] = 0x00;
    rom[18] = 0x80;
    
    let mut console = Console::from_rom_bytes(&rom).unwrap();
    
    // Run 10 frames using tick() and count ticks per frame
    let mut total_ticks: u64 = 0;
    for frame_num in 0..10 {
        let start_frame = console.frame_count();
        let mut ticks_this_frame = 0u64;
        
        while console.frame_count() == start_frame {
            console.tick();
            ticks_this_frame += 1;
        }
        
        total_ticks += ticks_this_frame;
        // Each tick = 1 CPU cycle = 3 PPU dots
        println!("Frame {}: {} ticks ({} PPU dots)", 
                 frame_num, ticks_this_frame, ticks_this_frame * 3);
    }
    
    let avg_ticks = total_ticks / 10;
    let avg_dots = total_ticks * 3 / 10;
    println!();
    println!("Average: {} ticks per frame ({} PPU dots)", avg_ticks, avg_dots);
    println!("Expected: 29780-29781 ticks (89340-89342 PPU dots)");
}
