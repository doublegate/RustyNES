// Simple test to check if framebuffer gets populated after running frames
use rustynes_core::Console;
use std::fs;

fn main() {
    // Try to find a test ROM
    let rom_paths = [
        "test-roms/cpu/nestest.nes",
        "test-roms/ppu/sprite_hit_tests_2005.09.19/sprite_hit_timing.nes",
    ];
    
    for rom_path in rom_paths.iter() {
        if let Ok(rom_data) = fs::read(rom_path) {
            println!("Testing with ROM: {}", rom_path);
            
            let mut console = Console::from_rom_bytes(&rom_data).unwrap();
            
            // Run a few frames
            for frame in 0..60 {
                console.step_frame_accurate();
                
                // Check framebuffer
                let fb = console.framebuffer();
                let non_zero_count: usize = fb.iter().filter(|&&x| x != 0).count();
                let total = fb.len();
                
                if frame % 10 == 0 {
                    println!("Frame {}: {}/{} non-zero pixels ({:.1}%)", 
                        frame, non_zero_count, total, 
                        (non_zero_count as f64 / total as f64) * 100.0);
                }
            }
            
            // Final check
            let fb = console.framebuffer();
            let non_zero_count: usize = fb.iter().filter(|&&x| x != 0).count();
            println!("Final: {}/{} non-zero pixels", non_zero_count, fb.len());
            
            if non_zero_count == 0 {
                println!("WARNING: Framebuffer is ALL ZEROS!");
            } else {
                println!("OK: Framebuffer has rendered pixels");
            }
            
            return;
        }
    }
    
    println!("No test ROM found");
}
