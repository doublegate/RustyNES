//! Quick validation test for Super Mario Bros ROM
//! This tests graphics and audio generation without requiring GUI

use std::fs;

fn main() {
    let rom_path = "/home/parobek/Code/RustyNES/game-roms/Super Mario Bros.nes";
    
    println!("=== RustyNES Super Mario Bros Validation Test ===\n");
    
    // Load ROM
    println!("1. Loading ROM: {}", rom_path);
    let rom_data = match fs::read(rom_path) {
        Ok(data) => {
            println!("   ROM size: {} bytes", data.len());
            data
        }
        Err(e) => {
            println!("   ERROR: Failed to read ROM: {}", e);
            return;
        }
    };
    
    // Parse ROM header
    if rom_data.len() >= 16 && &rom_data[0..4] == b"NES\x1a" {
        let prg_banks = rom_data[4];
        let chr_banks = rom_data[5];
        let mapper = ((rom_data[6] >> 4) | (rom_data[7] & 0xF0)) as u16;
        println!("   Format: iNES");
        println!("   PRG-ROM: {} x 16KB = {} KB", prg_banks, prg_banks as u32 * 16);
        println!("   CHR-ROM: {} x 8KB = {} KB", chr_banks, chr_banks as u32 * 8);
        println!("   Mapper: {} (NROM)", mapper);
    }
    
    // Create console
    println!("\n2. Creating console...");
    let console_result: Result<rustynes_core::Console, _> = 
        rustynes_core::Console::from_rom_bytes(&rom_data);
    
    let mut console = match console_result {
        Ok(c) => {
            println!("   Console created successfully");
            c
        }
        Err(e) => {
            println!("   ERROR: Failed to create console: {:?}", e);
            return;
        }
    };
    
    // Run frames and collect statistics
    println!("\n3. Running 100 frames in cycle-accurate mode...");
    
    let mut total_non_zero_pixels = 0u64;
    let mut total_audio_samples = 0usize;
    let mut frames_with_graphics = 0u32;
    let mut min_non_zero = usize::MAX;
    let mut max_non_zero = 0usize;
    
    for frame in 0..100 {
        console.step_frame_accurate();
        
        // Check framebuffer
        let fb = console.framebuffer();
        let non_zero_count = fb.iter().filter(|&&p| p != 0).count();
        total_non_zero_pixels += non_zero_count as u64;
        
        if non_zero_count > 0 {
            frames_with_graphics += 1;
            min_non_zero = min_non_zero.min(non_zero_count);
            max_non_zero = max_non_zero.max(non_zero_count);
        }
        
        // Check audio samples
        let samples = console.audio_samples();
        total_audio_samples += samples.len();
        
        // Clear audio buffer each frame (like desktop app does)
        console.clear_audio_samples();
        
        // Log progress every 25 frames
        if (frame + 1) % 25 == 0 {
            println!("   Frame {}: {} non-zero pixels, {} audio samples/frame", 
                     frame + 1, non_zero_count, samples.len());
        }
    }
    
    // Print results
    println!("\n=== Validation Results ===\n");
    
    println!("Graphics Output:");
    println!("   Frames with visible content: {}/100", frames_with_graphics);
    println!("   Avg non-zero pixels/frame: {}", total_non_zero_pixels / 100);
    println!("   Range: {} - {} non-zero pixels", 
             if min_non_zero == usize::MAX { 0 } else { min_non_zero }, 
             max_non_zero);
    
    println!("\nAudio Output:");
    println!("   Total audio samples: {}", total_audio_samples);
    println!("   Avg samples/frame: {}", total_audio_samples / 100);
    
    // Determine pass/fail
    println!("\n=== Test Verdict ===\n");
    
    let graphics_ok = frames_with_graphics >= 90 && total_non_zero_pixels > 1_000_000;
    let audio_ok = total_audio_samples > 50_000;
    
    if graphics_ok {
        println!("Graphics: PASS ({}% frames have content, {} total pixels)", 
                 frames_with_graphics, total_non_zero_pixels);
    } else {
        println!("Graphics: FAIL (insufficient visible content)");
    }
    
    if audio_ok {
        println!("Audio: PASS ({} samples generated)", total_audio_samples);
    } else {
        println!("Audio: FAIL (insufficient audio output)");
    }
    
    if graphics_ok && audio_ok {
        println!("\nOVERALL: PASS - Emulator is generating valid output");
    } else {
        println!("\nOVERALL: FAIL - Emulator has issues");
    }
}
