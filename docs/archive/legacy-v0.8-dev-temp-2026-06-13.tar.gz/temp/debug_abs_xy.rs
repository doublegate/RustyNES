//! Debug script to trace cpu_instr_06_abs_xy execution

use rustynes_core::Console;
use std::path::PathBuf;

fn main() {
    let rom_path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("..")
        .join("..")
        .join("test-roms")
        .join("cpu")
        .join("cpu_instr_06_abs_xy.nes");

    if !rom_path.exists() {
        eprintln!("ROM not found: {}", rom_path.display());
        return;
    }

    println!("Loading ROM: {}", rom_path.display());
    let rom_data = std::fs::read(&rom_path).expect("Failed to read ROM");
    let mut console = Console::from_rom_bytes(&rom_data).expect("Failed to create console");

    // Run for a limited number of frames with status checks
    for frame in 0..50 {
        console.step_frame();

        let status = console.peek_memory(0x6000);

        if frame % 10 == 0 {
            println!("Frame {}: Status = 0x{:02X}", frame, status);
        }

        // Check if test completed
        match status {
            0x00 => {
                println!("✓ Test PASSED at frame {}", frame);
                return;
            }
            0x80 => {
                // Still running
            }
            _ => {
                println!("✗ Test FAILED at frame {} with status 0x{:02X}", frame, status);

                // Try to read error text
                let mut error_text = String::new();
                for i in 0..256 {
                    let ch = console.peek_memory(0x6004 + i);
                    if ch == 0 {
                        break;
                    }
                    if ch.is_ascii() && ch >= 0x20 {
                        error_text.push(ch as char);
                    }
                }

                if !error_text.is_empty() {
                    println!("Error: {}", error_text);
                }
                return;
            }
        }
    }

    println!("✗ Test timed out after 50 frames");
    let final_status = console.peek_memory(0x6000);
    println!("Final status: 0x{:02X}", final_status);
}
