# Testing AbsoluteX Addressing Trace

## Expected behavior for `LDA $1234,X` with X=$10:

### Cycle-by-cycle breakdown:
1. **Cycle 1**: Fetch opcode (0xBD) from PC
2. **Cycle 2**: Fetch low byte ($34) from PC+1
3. **Cycle 3**: Fetch high byte ($12) from PC+2
4. **Cycle 4 (if page cross)**: Read from incorrect address $1244 (or skip if no page cross)
5. **Cycle 5**: Read from correct address $1244

In this case, no page crossing, so:
- base = $1234
- addr = $1244
- page_crossed = false (both in page $12xx)
- For READ: dummy read ONLY if page_crossed = false, so NO dummy read
- Final: Read from $1244

## Expected behavior for `STA $1234,X` with X=$10:

### Cycle-by-cycle breakdown:
1. **Cycle 1**: Fetch opcode (0x9D) from PC
2. **Cycle 2**: Fetch low byte ($34) from PC+1
3. **Cycle 3**: Fetch high byte ($12) from PC+2
4. **Cycle 4**: Read from address $1244 (dummy read, ALWAYS for writes)
5. **Cycle 5**: Write to correct address $1244

For WRITE: dummy read ALWAYS happens, even without page cross.

## Expected behavior for `INC $1234,X` with X=$10:

### Cycle-by-cycle breakdown:
1. **Cycle 1**: Fetch opcode (0xFE) from PC
2. **Cycle 2**: Fetch low byte ($34) from PC+1
3. **Cycle 3**: Fetch high byte ($12) from PC+2
4. **Cycle 4**: Read from address $1244 (dummy read during address calc, ALWAYS for RMW)
5. **Cycle 5**: Read from correct address $1244 (get value)
6. **Cycle 6**: Write original value to $1244 (dummy write)
7. **Cycle 7**: Write incremented value to $1244 (final write)

For RMW: dummy read ALWAYS happens, plus dummy write of original value.

## Current Implementation Analysis:

### read_operand():
- Dummy read only if `page_crossed == true` ✓ CORRECT for READ instructions

### write_operand():
- Dummy read ALWAYS for AbsoluteX/Y/IndirectIndexedY ✓ CORRECT for WRITE instructions

### RMW instructions (inc, dec, asl, etc.):
- Dummy read ALWAYS for AbsoluteX/Y/IndirectIndexedY ✓ CORRECT
- Dummy write of original value ✓ CORRECT

## Potential Issues:

1. ❌ NONE FOUND - logic appears correct

## Next Steps:

Check if test ROM has special requirements or if there's a bus conflict issue.
