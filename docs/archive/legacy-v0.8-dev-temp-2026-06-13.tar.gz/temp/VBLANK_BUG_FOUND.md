# CRITICAL BUG FOUND: PPU VBlank Flag Not Setting

**Date:** December 20, 2025
**Test:** cpu_dummy_reads.nes
**Root Cause:** PPU VBlank flag never sets during execution

---

## The Discovery

After extensive debugging with CPU instruction tracing, found that cpu_dummy_reads.nes is stuck in an infinite loop waiting for VBlank:

```assembly
E59E:  BIT $2002    ; Read PPU STATUS ($2002)
E5A1:  BPL $E59E    ; Branch if bit 7 (VBlank) clear
```

**Trace evidence:**
```
[TRACE] Cycle=25000 PC=E5A1 OP=10 A=00 X=FF Y=00 P=26
[TRACE] Cycle=25003 PC=E59E OP=2C A=00 X=FF Y=00 P=26
[TRACE] Cycle=25007 PC=E5A1 OP=10 A=00 X=FF Y=00 P=26
[TRACE] Cycle=25010 PC=E59E OP=2C A=00 X=FF Y=00 P=26
... (infinite loop continues)
```

- **BIT $2002** loads bit 7 of PPU STATUS into CPU N flag
- **BPL** branches if N flag is clear (VBlank not set)
- **Loop never exits** because VBlank flag is never set

---

## Why This Matters

This is the **REAL** reason cpu_dummy_reads.nes fails with 0xFF status:

1. ✓ ROM loads correctly (Mapper 3 CNROM)
2. ✓ RESET vector correct ($E57F)
3. ✓ CPU executes initialization code
4. ✓ Memory clearing loops complete
5. ✗ **VBlank wait loop hangs forever**
6. ✗ Test framework never runs
7. ✗ $6000 never written (remains 0xFF)

---

## Previous False Assumptions

**We thought:** Test ROM not executing → dummy read bug
**Reality:** Test ROM DOES execute → PPU VBlank bug

The dummy read implementation was actually CORRECT all along!

---

## PPU VBlank Expected Behavior

**Timing:**
- Frame = 262 scanlines (NTSC)
- VBlank starts at scanline 241
- VBlank flag (bit 7 of $2002) SET at start of scanline 241
- Reading $2002 clears VBlank flag
- NMI can be triggered if PPUCTRL bit 7 is set

**In our case:**
- Test runs for 11 frames before timeout
- Each frame should set VBlank at scanline 241
- ROM reads $2002 every ~7 cycles (BIT + BPL)
- VBlank should be readable for ~20 scanlines (241-260)

**But:** VBlank flag is NEVER set during any of those 11 frames!

---

## Next Steps

### Priority 1: Verify PPU VBlank Generation

Check if PPU is:
1. Counting scanlines correctly
2. Setting VBlank flag at scanline 241
3. Maintaining VBlank flag until $2002 read
4. Clearing VBlank flag on $2002 read

### Priority 2: Check PPU/CPU Synchronization

Verify:
1. PPU stepping 3 dots per CPU cycle
2. Frame timing (29780 CPU cycles = 262 scanlines)
3. PPU cycle counter accuracy

### Priority 3: Test with Passing ROM

Compare VBlank behavior:
- cpu_instr_01_implied.nes (passing) - does it wait for VBlank?
- cpu_dummy_reads.nes (failing) - same wait loop but never exits

---

## Impact on Other Tests

**This explains multiple test failures:**

- **cpu_dummy_reads.nes** - Stuck in VBlank wait
- **cpu_instr_06_abs_xy** - Possibly also VBlank-related timeout
- **Other timeouts** - May all be VBlank bugs

**Tests that pass:**
- Likely don't wait for VBlank in their initialization
- Or VBlank happens to work in specific timing scenarios

---

## Code Locations to Check

### PPU VBlank Flag Management

**File:** `/home/parobek/Code/RustyNES/crates/rustynes-ppu/src/ppu.rs`

**Check:**
1. VBlank flag setting at scanline 241
2. VBlank flag clearing on $2002 read
3. Scanline counter logic
4. Frame timing

### Bus PPU Register Routing

**File:** `/home/parobek/Code/RustyNES/crates/rustynes-core/src/bus.rs`

**Verify:**
- $2002 reads route to PPU correctly ✓ (already verified)
- $2000-$3FFF mirroring works ✓ (already verified)

### Console PPU Stepping

**File:** `/home/parobek/Code/RustyNES/crates/rustynes-core/src/console.rs`

**Verify:**
- PPU steps 3 dots per CPU cycle
- Frame completion detection
- NMI triggering

---

## Conclusion

**The cpu_dummy_reads investigation led us to the REAL bug:**

❌ **NOT**: Dummy read implementation
✅ **YES**: PPU VBlank flag generation

This is actually GOOD NEWS:
1. Our CPU dummy read implementation is correct
2. We found a critical PPU timing bug
3. Fixing this will likely fix multiple test failures
4. The investigation methodology was sound

**Recommendation:** Shift focus to PPU VBlank debugging immediately.
