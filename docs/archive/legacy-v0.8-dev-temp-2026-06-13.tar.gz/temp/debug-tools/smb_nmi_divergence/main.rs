//! Trace cycle drift and NMI divergence between step() and tick() modes

use std::fs;
use rustynes_mappers::{Rom, create_mapper};
use rustynes_core::Console;

fn main() {
    println!("=== Cycle Drift Investigation ===\n");

    let smb_path = "/home/parobek/Code/RustyNES/game-roms/Super Mario Bros.nes";
    let rom_data = fs::read(smb_path).expect("Failed to read ROM");

    println!("Running both modes and tracking cycle drift...\n");

    let rom1 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper1 = create_mapper(&rom1).expect("Failed to create mapper");
    let mut console_step = Console::with_sample_rate(mapper1, 44100);

    let rom2 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper2 = create_mapper(&rom2).expect("Failed to create mapper");
    let mut console_tick = Console::with_sample_rate(mapper2, 44100);

    // Track when drift begins
    let mut last_diff: i64 = 0;
    let mut drift_count = 0;

    // Run both modes until divergence or max instructions
    const MAX_INSTRUCTIONS: u64 = 500000;
    for i in 0..MAX_INSTRUCTIONS {
        // Save state BEFORE execution
        let pc_step_before = console_step.cpu().pc;
        let pc_tick_before = console_tick.cpu().pc;

        // Execute one instruction in each mode
        let step_cycles = console_step.step() as u64;
        let pc_step_after = console_step.cpu().pc;

        let mut tick_cycles = 0u64;
        loop {
            let (instr_complete, _) = console_tick.tick();
            tick_cycles += 1;
            if instr_complete { break; }
            // DMA takes 513-514 cycles, so allow up to 600
            if tick_cycles > 600 {
                println!("STUCK at instruction {}! (tick_cycles={})", i, tick_cycles);
                return;
            }
        }
        let pc_tick_after = console_tick.cpu().pc;

        let diff = console_tick.cycles() as i64 - console_step.cycles() as i64;

        // Report when drift changes (limit to first 5 drift events with full detail)
        if diff != last_diff {
            drift_count += 1;
            if drift_count <= 5 {
                if last_diff == 0 && diff != 0 {
                    println!("*** DRIFT STARTED at instruction {} ***", i);
                }
                println!("Instr {}: step 0x{:04X}->0x{:04X} ({}cyc), tick 0x{:04X}->0x{:04X} ({}cyc), diff: {} -> {}",
                         i, pc_step_before, pc_step_after, step_cycles,
                         pc_tick_before, pc_tick_after, tick_cycles,
                         last_diff, diff);
            } else if drift_count == 6 {
                println!("... (suppressing further drift messages)");
            }
            last_diff = diff;
        }

        // Check for PC divergence
        if pc_step_after != pc_tick_after {
            println!("\n*** PC DIVERGED at instruction {} ***", i);
            println!("  Before: step PC=0x{:04X}, tick PC=0x{:04X}", pc_step_before, pc_tick_before);
            println!("  After:  step PC=0x{:04X} ({}cyc), tick PC=0x{:04X} ({}cyc)",
                     pc_step_after, step_cycles, pc_tick_after, tick_cycles);
            println!("  step SP=0x{:02X}, cycles={}",
                     console_step.cpu().sp, console_step.cycles());
            println!("  tick SP=0x{:02X}, cycles={}",
                     console_tick.cpu().sp, console_tick.cycles());

            // Analyze what happened
            if step_cycles == 7 {
                println!("\nstep() mode executed NMI/IRQ (7 cycles) - jumped to interrupt handler");
            }
            if tick_cycles == 3 {
                println!("tick() mode executed branch instruction (3 cycles) - missed NMI!");
            }
            println!("\nThe cycle drift of {} caused NMI timing mismatch.", diff);
            println!("Total drift events observed: {}", drift_count);
            break;
        }
    }
}
