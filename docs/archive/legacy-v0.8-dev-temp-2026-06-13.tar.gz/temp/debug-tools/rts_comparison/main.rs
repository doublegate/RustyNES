use rustynes_cpu::{Cpu, Bus};

struct TestBus {
    memory: [u8; 0x10000],
}

impl TestBus {
    fn new() -> Self {
        Self { memory: [0; 0x10000] }
    }
}

impl Bus for TestBus {
    fn read(&mut self, addr: u16) -> u8 {
        self.memory[addr as usize]
    }
    fn write(&mut self, addr: u16, value: u8) {
        self.memory[addr as usize] = value;
    }
}

fn main() {
    println!("=== RTS Step vs Tick Comparison ===\n");

    // Test: Simple JSR/RTS
    println!("Test: JSR $8010, RTS at $8010, should return to $8003");

    let step_pc;
    let tick_pc;

    // Step mode
    {
        let mut cpu = Cpu::new();
        let mut bus = TestBus::new();

        bus.memory[0x8000] = 0x20; // JSR
        bus.memory[0x8001] = 0x10;
        bus.memory[0x8002] = 0x80;
        bus.memory[0x8010] = 0x60; // RTS
        bus.memory[0xFFFC] = 0x00;
        bus.memory[0xFFFD] = 0x80;

        cpu.reset(&mut bus);
        println!("  After reset: PC=0x{:04X}, SP=0x{:02X}", cpu.pc, cpu.sp);

        let jsr_cycles = cpu.step(&mut bus);
        println!("  After JSR (step): PC=0x{:04X}, SP=0x{:02X}, cycles={}", cpu.pc, cpu.sp, jsr_cycles);
        
        let sp = cpu.sp;
        let stack_lo = bus.memory[0x0100 + sp.wrapping_add(1) as usize];
        let stack_hi = bus.memory[0x0100 + sp.wrapping_add(2) as usize];
        println!("  Stack: [SP+1]=0x{:02X}, [SP+2]=0x{:02X} -> addr=0x{:02X}{:02X}", 
                 stack_lo, stack_hi, stack_hi, stack_lo);

        let rts_cycles = cpu.step(&mut bus);
        println!("  After RTS (step): PC=0x{:04X}, SP=0x{:02X}, cycles={}", cpu.pc, cpu.sp, rts_cycles);
        step_pc = cpu.pc;
    }

    println!();

    // Tick mode
    {
        let mut cpu = Cpu::new();
        let mut bus = TestBus::new();

        bus.memory[0x8000] = 0x20;
        bus.memory[0x8001] = 0x10;
        bus.memory[0x8002] = 0x80;
        bus.memory[0x8010] = 0x60;
        bus.memory[0xFFFC] = 0x00;
        bus.memory[0xFFFD] = 0x80;

        cpu.reset(&mut bus);
        println!("  After reset: PC=0x{:04X}, SP=0x{:02X}", cpu.pc, cpu.sp);

        let mut jsr_cycles = 0u32;
        loop {
            let complete = cpu.tick(&mut bus);
            jsr_cycles += 1;
            if complete { break; }
            if jsr_cycles > 20 { println!("STUCK JSR!"); return; }
        }
        println!("  After JSR (tick): PC=0x{:04X}, SP=0x{:02X}, cycles={}", cpu.pc, cpu.sp, jsr_cycles);
        
        let sp = cpu.sp;
        let stack_lo = bus.memory[0x0100 + sp.wrapping_add(1) as usize];
        let stack_hi = bus.memory[0x0100 + sp.wrapping_add(2) as usize];
        println!("  Stack: [SP+1]=0x{:02X}, [SP+2]=0x{:02X} -> addr=0x{:02X}{:02X}", 
                 stack_lo, stack_hi, stack_hi, stack_lo);

        let mut rts_cycles = 0u32;
        loop {
            let complete = cpu.tick(&mut bus);
            rts_cycles += 1;
            if complete { break; }
            if rts_cycles > 20 { println!("STUCK RTS!"); return; }
        }
        println!("  After RTS (tick): PC=0x{:04X}, SP=0x{:02X}, cycles={}", cpu.pc, cpu.sp, rts_cycles);
        tick_pc = cpu.pc;
    }

    println!();
    if step_pc == tick_pc {
        println!("SUCCESS: Both step and tick returned to PC=0x{:04X}", step_pc);
    } else {
        println!("FAILURE: step PC=0x{:04X}, tick PC=0x{:04X} (diff={})", 
                 step_pc, tick_pc, tick_pc as i32 - step_pc as i32);
    }
}
