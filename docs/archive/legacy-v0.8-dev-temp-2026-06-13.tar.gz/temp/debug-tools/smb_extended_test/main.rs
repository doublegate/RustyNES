use std::fs;
use rustynes_mappers::{Rom, create_mapper};
use rustynes_core::Console;

fn main() {
    println!("=== Investigating Divergence at Instruction 66891 ===\n");

    let smb_path = "/home/parobek/Code/RustyNES/game-roms/Super Mario Bros.nes";
    let rom_data = fs::read(smb_path).expect("Failed to read ROM");

    let rom1 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper1 = create_mapper(&rom1).expect("Failed to create mapper");
    let mut console_step = Console::with_sample_rate(mapper1, 44100);

    let rom2 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper2 = create_mapper(&rom2).expect("Failed to create mapper");
    let mut console_tick = Console::with_sample_rate(mapper2, 44100);

    // Run to instruction 66885 (a few before divergence)
    const TARGET: u64 = 66885;
    
    println!("Running to instruction {}...", TARGET);
    for _i in 0..TARGET {
        console_step.step();
        loop {
            let (instr_complete, _) = console_tick.tick();
            if instr_complete { break; }
        }
    }
    
    // Now trace the next several instructions
    println!("\nTracing instructions from {}...\n", TARGET);
    for i in 0..20 {
        let instr_num = TARGET + i;
        let pc_step = console_step.cpu().pc;
        let pc_tick = console_tick.cpu().pc;
        let sp_step = console_step.cpu().sp;
        let sp_tick = console_tick.cpu().sp;
        
        // Check state BEFORE execution
        if pc_step != pc_tick || sp_step != sp_tick {
            println!("*** DIVERGENCE at instruction {} (before exec) ***", instr_num);
            println!("  step: PC=0x{:04X}, SP=0x{:02X}", pc_step, sp_step);
            println!("  tick: PC=0x{:04X}, SP=0x{:02X}", pc_tick, sp_tick);
            break;
        }
        
        let step_cycles = console_step.step();
        let mut tick_cycles = 0u64;
        loop {
            let (instr_complete, _) = console_tick.tick();
            tick_cycles += 1;
            if instr_complete { break; }
            if tick_cycles > 100 {
                println!("STUCK at instruction {}!", instr_num);
                return;
            }
        }
        
        let pc_step_after = console_step.cpu().pc;
        let pc_tick_after = console_tick.cpu().pc;
        let sp_step_after = console_step.cpu().sp;
        let sp_tick_after = console_tick.cpu().sp;
        
        // Show instruction details
        println!("Instr {}: PC 0x{:04X}->0x{:04X}, SP 0x{:02X}->0x{:02X}, {} step cycles, {} tick cycles{}",
                 instr_num, pc_step, pc_step_after, sp_step, sp_step_after, 
                 step_cycles, tick_cycles,
                 if pc_step_after != pc_tick_after || sp_step_after != sp_tick_after { " **DIVERGED**" } else { "" });
        
        if pc_step_after != pc_tick_after {
            println!("  PC diverged: step=0x{:04X}, tick=0x{:04X}", pc_step_after, pc_tick_after);
        }
        if sp_step_after != sp_tick_after {
            println!("  SP diverged: step=0x{:02X}, tick=0x{:02X}", sp_step_after, sp_tick_after);
        }
        if step_cycles != tick_cycles as u8 {
            println!("  Cycles diverged: step={}, tick={}", step_cycles, tick_cycles);
        }
        
        if pc_step_after != pc_tick_after || sp_step_after != sp_tick_after {
            break;
        }
    }
}
