//! Detailed branch instruction trace to understand cycle discrepancy

use std::fs;
use rustynes_mappers::{Rom, create_mapper};
use rustynes_core::Console;

fn main() {
    println!("=== Branch Instruction Cycle Trace (Comparing step vs tick) ===\n");

    let smb_path = "/home/parobek/Code/RustyNES/game-roms/Super Mario Bros.nes";
    let rom_data = fs::read(smb_path).expect("Failed to read ROM");

    // Check the opcode at address 0x8E6C directly from ROM
    // iNES header is 16 bytes, PRG ROM starts at offset 16
    // For NROM (mapper 0), PRG is mapped at $8000-$FFFF
    // Address 0x8E6C in CPU space = 0x8E6C - 0x8000 = 0x0E6C in PRG ROM
    // Plus 16 bytes for iNES header = offset 0x0E7C
    let prg_offset = 0x8E6C - 0x8000;
    let file_offset = 16 + prg_offset;
    let opcode = rom_data[file_offset];
    let operand = rom_data[file_offset + 1];
    println!("ROM byte at 0x8E6C: opcode=0x{:02X}, next byte=0x{:02X}\n", opcode, operand);

    // Create TWO consoles - one for step mode, one for tick mode
    let rom1 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper1 = create_mapper(&rom1).expect("Failed to create mapper");
    let mut console_step = Console::with_sample_rate(mapper1, 44100);

    let rom2 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper2 = create_mapper(&rom2).expect("Failed to create mapper");
    let mut console_tick = Console::with_sample_rate(mapper2, 44100);

    // Run until we get near the first branch at PC 0x8E6C (around instruction 36659)
    const SKIP_TO: u64 = 36655;

    println!("Running to instruction {} in both modes...\n", SKIP_TO);
    for _i in 0..SKIP_TO {
        console_step.step();
        loop {
            let (instr_complete, _) = console_tick.tick();
            if instr_complete { break; }
        }
    }

    // Now trace instructions in detail, comparing step vs tick
    println!("Detailed trace from instruction {}:\n", SKIP_TO);
    println!("{:>6} | {:^25} | {:^25} |", "Instr", "STEP MODE", "TICK MODE");
    println!("{:->6}-+-{:->25}-+-{:->25}-+", "", "", "");

    for instr_num in 0..20 {
        let instr_id = SKIP_TO + instr_num;

        // Get state before for both modes
        let pc_step_before = console_step.cpu().pc;
        let pc_tick_before = console_tick.cpu().pc;
        let status_step = console_step.cpu().status;
        let status_tick = console_tick.cpu().status;

        // Execute step mode
        let step_cycles = console_step.step();
        let pc_step_after = console_step.cpu().pc;

        // Execute tick mode with detailed trace
        let mut tick_cycles = 0u32;
        let mut state_trace = String::new();
        loop {
            let state_before = console_tick.cpu().get_state();
            let pc_before_tick = console_tick.cpu().pc;
            let (instr_complete, _) = console_tick.tick();
            let state_after = console_tick.cpu().get_state();
            let pc_after_tick = console_tick.cpu().pc;
            tick_cycles += 1;

            // Log state transition for branches at 0x8E6C
            if pc_tick_before == 0x8E6C {
                state_trace.push_str(&format!("\n         Tick {}: {:?}(PC:{:04X}) -> {:?}(PC:{:04X}) {}",
                    tick_cycles, state_before, pc_before_tick,
                    state_after, pc_after_tick,
                    if instr_complete { "[DONE]" } else { "" }));
            }

            if instr_complete { break; }
            if tick_cycles > 20 {
                println!("STUCK!");
                return;
            }
        }
        let pc_tick_after = console_tick.cpu().pc;

        // Check for divergence
        let pc_match = pc_step_after == pc_tick_after;
        let cycle_match = step_cycles as u32 == tick_cycles;
        let marker = if !pc_match { "**PC**" } else if !cycle_match { "*cyc*" } else { "" };

        // Special detail for branches at 0x8E6C
        if pc_step_before == 0x8E6C || !pc_match || !cycle_match {
            println!("{:>6} | PC:{:04X}->{:04X} cyc:{:>2}   | PC:{:04X}->{:04X} cyc:{:>2}   | {}",
                     instr_id,
                     pc_step_before, pc_step_after, step_cycles,
                     pc_tick_before, pc_tick_after, tick_cycles,
                     marker);

            if pc_step_before == 0x8E6C {
                // This is a branch - show status flags and state trace
                println!("       | Status: {:02X}             | Status: {:02X}             |",
                         status_step.bits(), status_tick.bits());
                println!("       STATE TRACE:{}", state_trace);
            }
        } else {
            println!("{:>6} | PC:{:04X}->{:04X} cyc:{:>2}   | PC:{:04X}->{:04X} cyc:{:>2}   |",
                     instr_id,
                     pc_step_before, pc_step_after, step_cycles,
                     pc_tick_before, pc_tick_after, tick_cycles);
        }

        if !pc_match {
            println!("\n*** PC DIVERGENCE at instruction {} ***\n", instr_id);
            break;
        }
    }
}
