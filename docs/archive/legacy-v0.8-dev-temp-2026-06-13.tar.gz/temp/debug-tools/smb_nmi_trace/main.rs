//! Trace the instruction at divergence point 29037

use std::fs;
use rustynes_mappers::{Rom, create_mapper};
use rustynes_core::Console;

fn main() {
    println!("=== Tracing Instruction 29037 ===\n");

    let smb_path = "/home/parobek/Code/RustyNES/game-roms/Super Mario Bros.nes";
    let rom_data = fs::read(smb_path).expect("Failed to read ROM");

    let rom1 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper1 = create_mapper(&rom1).expect("Failed to create mapper");
    let mut console_step = Console::with_sample_rate(mapper1, 44100);

    let rom2 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper2 = create_mapper(&rom2).expect("Failed to create mapper");
    let mut console_tick = Console::with_sample_rate(mapper2, 44100);

    // Run to instruction 29036 (one before the instruction we want to trace)
    println!("Running to instruction 29036...\n");
    for _i in 0..29036 {
        console_step.step();
        loop {
            let (instr_complete, _) = console_tick.tick();
            if instr_complete { break; }
        }
    }

    // Verify state matches
    println!("State at instruction 29036:");
    println!("  step PC: 0x{:04X}, SP: 0x{:02X}, cycles: {}",
             console_step.cpu().pc, console_step.cpu().sp, console_step.cycles());
    println!("  tick PC: 0x{:04X}, SP: 0x{:02X}, cycles: {}",
             console_tick.cpu().pc, console_tick.cpu().sp, console_tick.cycles());

    // Check if there's divergence at this point
    if console_step.cpu().pc != console_tick.cpu().pc {
        println!("\n*** ALREADY DIVERGED at instruction 29036 ***");
        println!("  step PC: 0x{:04X}", console_step.cpu().pc);
        println!("  tick PC: 0x{:04X}", console_tick.cpu().pc);
        return;
    }

    // Execute instruction 29036 (before RTS)
    println!("\nExecuting instruction 29036:");
    let pc_step_36 = console_step.cpu().pc;
    let pc_tick_36 = console_tick.cpu().pc;
    let step_cycles_36 = console_step.step();
    let mut tick_cycles_36 = 0u64;
    loop {
        let (instr_complete, _) = console_tick.tick();
        tick_cycles_36 += 1;
        if instr_complete { break; }
    }
    println!("  step: PC 0x{:04X} -> 0x{:04X}, {} cycles",
             pc_step_36, console_step.cpu().pc, step_cycles_36);
    println!("  tick: PC 0x{:04X} -> 0x{:04X}, {} cycles",
             pc_tick_36, console_tick.cpu().pc, tick_cycles_36);

    // Now execute instruction 29037
    println!("\nExecuting instruction 29037 (at 0x{:04X}):", console_step.cpu().pc);
    let pc_step_before = console_step.cpu().pc;
    let pc_tick_before = console_tick.cpu().pc;
    let sp_step_before = console_step.cpu().sp;
    let sp_tick_before = console_tick.cpu().sp;

    println!("  step before: PC=0x{:04X}, SP=0x{:02X}", pc_step_before, sp_step_before);
    println!("  tick before: PC=0x{:04X}, SP=0x{:02X}", pc_tick_before, sp_tick_before);

    // Execute
    let step_cycles = console_step.step();
    let mut tick_cycles = 0u64;
    loop {
        let (instr_complete, _) = console_tick.tick();
        tick_cycles += 1;
        if instr_complete { break; }
        if tick_cycles > 20 {
            println!("STUCK!");
            return;
        }
    }

    let pc_step_after = console_step.cpu().pc;
    let pc_tick_after = console_tick.cpu().pc;
    let sp_step_after = console_step.cpu().sp;
    let sp_tick_after = console_tick.cpu().sp;

    println!("\nResults for instruction 29037:");
    println!("  step: PC 0x{:04X} -> 0x{:04X}, SP 0x{:02X} -> 0x{:02X}, {} cycles",
             pc_step_before, pc_step_after, sp_step_before, sp_step_after, step_cycles);
    println!("  tick: PC 0x{:04X} -> 0x{:04X}, SP 0x{:02X} -> 0x{:02X}, {} cycles",
             pc_tick_before, pc_tick_after, sp_tick_before, sp_tick_after, tick_cycles);

    if pc_step_after != pc_tick_after {
        println!("\n*** PC DIVERGED at instruction 29037 ***");
        println!("  step -> 0x{:04X}", pc_step_after);
        println!("  tick -> 0x{:04X}", pc_tick_after);
        println!("  difference: {} (tick - step)", pc_tick_after as i32 - pc_step_after as i32);
    } else {
        println!("\n=== SUCCESS: step and tick match at instruction 29037 ===");

        // Continue running to check for later divergence
        println!("\nContinuing for 1000 more instructions...");
        for i in 0..1000 {
            console_step.step();
            loop {
                let (instr_complete, _) = console_tick.tick();
                if instr_complete { break; }
            }
            if console_step.cpu().pc != console_tick.cpu().pc {
                println!("\nDivergence found at instruction {} (29037 + {})", 29037 + i + 1, i + 1);
                println!("  step PC: 0x{:04X}", console_step.cpu().pc);
                println!("  tick PC: 0x{:04X}", console_tick.cpu().pc);
                return;
            }
        }
        println!("No divergence found in next 1000 instructions!");
    }
}
