//! Compare when pixels first appear in both modes

use std::fs;

fn main() {
    let rom_path = "/home/parobek/Code/RustyNES/game-roms/Super Mario Bros.nes";
    let rom_data = fs::read(rom_path).expect("Failed to read ROM");

    println!("=== Pixel Appearance Comparison ===\n");

    // Test step_frame() mode
    println!("--- step_frame() mode ---");
    {
        let mut console = rustynes_core::Console::from_rom_bytes(&rom_data)
            .expect("Failed to create console");

        for frame in 0..50 {
            console.step_frame();
            let fb = console.framebuffer();
            let non_zero = fb.iter().filter(|&&p| p != 0).count();
            if non_zero > 0 {
                println!("First pixels at frame {}: {} non-zero pixels", frame, non_zero);
                println!("  cycles: {}", console.cycles());
                break;
            }
        }
    }

    // Test step_frame_accurate() mode
    println!("\n--- step_frame_accurate() mode ---");
    {
        let mut console = rustynes_core::Console::from_rom_bytes(&rom_data)
            .expect("Failed to create console");

        for frame in 0..50 {
            console.step_frame_accurate();
            let fb = console.framebuffer();
            let non_zero = fb.iter().filter(|&&p| p != 0).count();
            if frame % 10 == 0 || non_zero > 0 {
                println!("Frame {}: {} non-zero pixels, cycles: {}",
                         frame, non_zero, console.cycles());
            }
            if non_zero > 0 {
                break;
            }
        }
    }

    // Let's compare PPUMASK status at key frames
    println!("\n--- PPUMASK comparison ---");
    {
        let mut c1 = rustynes_core::Console::from_rom_bytes(&rom_data).unwrap();
        let mut c2 = rustynes_core::Console::from_rom_bytes(&rom_data).unwrap();

        for frame in 0..40 {
            c1.step_frame();
            c2.step_frame_accurate();

            let mask1 = c1.bus().ppu.mask().bits();
            let mask2 = c2.bus().ppu.mask().bits();

            if mask1 != mask2 || (frame % 10 == 0) {
                println!("Frame {}: step PPUMASK=0x{:02X}, tick PPUMASK=0x{:02X}{}",
                         frame, mask1, mask2,
                         if mask1 != mask2 { " <-- DIFFERENT!" } else { "" });
            }

            // Check if rendering is enabled
            if mask1 & 0x18 != 0 && mask2 & 0x18 == 0 {
                println!("  step has rendering enabled, tick does NOT!");
            }
        }
    }
}
