//! Compare framebuffer output between step() and tick() modes

use std::fs;
use rustynes_mappers::{Rom, create_mapper};
use rustynes_core::Console;

fn main() {
    println!("=== Framebuffer Comparison: step() vs tick() ===\n");

    let smb_path = "/home/parobek/Code/RustyNES/game-roms/Super Mario Bros.nes";
    let rom_data = fs::read(smb_path).expect("Failed to read ROM");

    // Create two consoles
    let rom1 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper1 = create_mapper(&rom1).expect("Failed to create mapper");
    let mut console_step = Console::with_sample_rate(mapper1, 44100);

    let rom2 = Rom::load(&rom_data).expect("Failed to parse ROM");
    let mapper2 = create_mapper(&rom2).expect("Failed to create mapper");
    let mut console_tick = Console::with_sample_rate(mapper2, 44100);

    // Run for several frames and compare
    for frame in 0..60 {
        console_step.step_frame();
        console_tick.step_frame_accurate();

        let fb_step = console_step.framebuffer();
        let fb_tick = console_tick.framebuffer();

        let non_zero_step: usize = fb_step.iter().filter(|&&x| x != 0).count();
        let non_zero_tick: usize = fb_tick.iter().filter(|&&x| x != 0).count();

        // Count differences
        let mut diff_count = 0;
        for i in 0..fb_step.len() {
            if fb_step[i] != fb_tick[i] {
                diff_count += 1;
            }
        }

        if frame % 10 == 0 || diff_count > 0 {
            let diff_pct = (diff_count as f64 / fb_step.len() as f64) * 100.0;
            println!(
                "Frame {:>3}: step={:>5} pixels, tick={:>5} pixels, diff={:>5} ({:.2}%)",
                frame, non_zero_step, non_zero_tick, diff_count, diff_pct
            );
        }

        // Check for critical issues
        if non_zero_step > 0 && non_zero_tick == 0 {
            println!("ERROR: step() has output but tick() is blank!");
            break;
        }
    }

    // Final comparison
    let fb_step = console_step.framebuffer();
    let fb_tick = console_tick.framebuffer();
    let non_zero_step: usize = fb_step.iter().filter(|&&x| x != 0).count();
    let non_zero_tick: usize = fb_tick.iter().filter(|&&x| x != 0).count();

    println!("\n=== Final Results ===");
    println!("step() mode: {} non-zero pixels", non_zero_step);
    println!("tick() mode: {} non-zero pixels", non_zero_tick);
    println!("step() cycles: {}", console_step.cycles());
    println!("tick() cycles: {}", console_tick.cycles());

    // Calculate similarity
    let mut matches = 0;
    for i in 0..fb_step.len() {
        if fb_step[i] == fb_tick[i] {
            matches += 1;
        }
    }
    let similarity = (matches as f64 / fb_step.len() as f64) * 100.0;
    println!("Framebuffer similarity: {:.2}%", similarity);

    if non_zero_tick > 0 {
        println!("\nSUCCESS: tick() mode produces visible output!");
    } else {
        println!("\nFAILURE: tick() mode produces blank screen!");
    }
}
