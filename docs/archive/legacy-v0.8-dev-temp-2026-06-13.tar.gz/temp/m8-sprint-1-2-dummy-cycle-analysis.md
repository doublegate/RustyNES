# M8 Sprint 1 & 2: Dummy Cycle Analysis

**Date:** December 20, 2025
**Author:** Analysis of CPU dummy read/write behavior
**Status:** Investigation in progress

---

## Test Failures Summary

| Test | Status | Signature | Issue |
|------|--------|-----------|-------|
| cpu_dummy_reads.nes | FAIL | 0xFF FF FF | Timing/cycle count mismatch |
| cpu_dummy_writes_ppumem.nes | TIMEOUT | Frame 227 | Never completes |
| cpu_instr_timing.nes | TIMEOUT | N/A | Never completes |
| cpu_instr_timing_1.nes | TIMEOUT | N/A | Never completes |

---

## Hardware Behavior: Indexed Addressing

### Absolute,X / Absolute,Y Addressing

According to NESdev documentation and CPU_TIMING_REFERENCE.md:

#### Read Instructions (LDA, LDX, LDY, ADC, etc.)
```
LDA $1234,X where X=$10

Cycle 1: Fetch opcode $BD
Cycle 2: Fetch address low $34
Cycle 3: Fetch address high $12
Cycle 4: DUMMY READ from ($1234 + $10) & $FF = $1244 (if no page cross)
         OR Read from wrong page if page crossed: $12 + ($34+$10)>>8 = $1244
Cycle 5: Read actual value from $1244 (only if page crossed)

Total: 4 cycles (no page cross) or 5 cycles (page crossed)
```

#### Write Instructions (STA, STX, STY)
```
STA $1234,X where X=$10

Cycle 1: Fetch opcode $9D
Cycle 2: Fetch address low $34
Cycle 3: Fetch address high $12
Cycle 4: DUMMY READ from wrong page (ALWAYS, even if no page cross)
Cycle 5: Write value to $1244

Total: ALWAYS 5 cycles (no page cross penalty because dummy read always happens)
```

#### Read-Modify-Write Instructions (ASL, LSR, ROL, ROR, INC, DEC)
```
ASL $1234,X where X=$10

Cycle 1: Fetch opcode $1E
Cycle 2: Fetch address low $34
Cycle 3: Fetch address high $12
Cycle 4: DUMMY READ from wrong page (ALWAYS)
Cycle 5: Read actual value from $1244
Cycle 6: Write old value back to $1244 (dummy write - TRIGGERS SIDE EFFECTS!)
Cycle 7: Write new value to $1244

Total: ALWAYS 7 cycles
```

---

## Current Implementation Analysis

### What's Correct

1. ✅ **RMW Dummy Writes**: All RMW instructions (INC, DEC, ASL, LSR, ROL, ROR, DCP, ISC, SLO, RLA, SRE, RRA) already perform dummy writes on lines 186, 200, 293, 316, 340, 369, 616, 630, 644, 660, 677, 693

2. ✅ **Page Crossing Detection**: `page_crossed()` function correctly detects 256-byte boundary crossings

3. ✅ **Cycle Counts**: Opcode table has correct base cycle counts

### What's Missing

1. ❌ **Indexed Addressing Dummy Reads**: The `AddressingMode::resolve()` function in `addressing.rs` does NOT perform dummy reads during address calculation

2. ❌ **Write vs Read Distinction**: Current implementation doesn't distinguish between read and write instructions when handling indexed addressing

3. ❌ **Zero Page,X/Y Dummy Reads**: Zero page indexed modes should also perform dummy reads

---

## Required Changes

### Option 1: Modify AddressingMode::resolve()

**Problem:** `resolve()` doesn't have access to bus for dummy reads, and it returns immediately without performing intermediate cycles.

**Solution:** Add a `resolve_with_dummy_reads()` variant that:
- Takes `&mut Bus` parameter
- Performs dummy reads for indexed modes
- Returns cycle count consumed

### Option 2: Move Addressing Resolution to Instructions

**Problem:** Current architecture separates address resolution from instruction execution.

**Solution:** Each instruction handles its own addressing, including dummy reads:
- Read instructions: conditional dummy read (only on page cross)
- Write instructions: unconditional dummy read
- RMW instructions: unconditional dummy read + dummy write

### Option 3: Hybrid Approach (RECOMMENDED)

Keep `resolve()` for simple modes, add instruction-specific helpers for complex modes:

```rust
// In instructions.rs
fn resolve_absolute_x_read(&mut self, bus: &mut impl Bus) -> (u16, u8) {
    let base = bus.read_u16(self.pc);
    self.pc += 2;

    let addr_no_carry = (base & 0xFF00) | ((base + self.x as u16) & 0x00FF);
    let addr_final = base.wrapping_add(self.x as u16);

    if page_crossed(base, addr_final) {
        bus.read(addr_no_carry); // Dummy read from wrong page
        (addr_final, 1) // +1 cycle penalty
    } else {
        (addr_final, 0)
    }
}

fn resolve_absolute_x_write(&mut self, bus: &mut impl Bus) -> u16 {
    let base = bus.read_u16(self.pc);
    self.pc += 2;

    let addr_no_carry = (base & 0xFF00) | ((base + self.x as u16) & 0x00FF);
    let addr_final = base.wrapping_add(self.x as u16);

    bus.read(addr_no_carry); // ALWAYS dummy read for writes
    addr_final
}
```

---

## Zero Page Indexed

### Current Implementation
```rust
Self::ZeroPageX => {
    let base = bus.read(pc);
    let addr = base.wrapping_add(x) as u16;
    AddressResult::new(addr)
}
```

### Required Implementation
```
LDA $80,X where X=$05

Cycle 1: Fetch opcode
Cycle 2: Fetch zero page address $80
Cycle 3: DUMMY READ from $0080 (before adding X)
Cycle 4: Read from $0085

Total: 4 cycles
```

---

## Impact on Cycle Counts

### Official Instructions Affected

| Opcode | Mnemonic | Current | Correct | Fix Needed |
|--------|----------|---------|---------|------------|
| 9D | STA Abs,X | 4* (+1 page cross) | 5 (always) | Yes |
| 99 | STA Abs,Y | 4* (+1 page cross) | 5 (always) | Yes |
| 91 | STA (Ind),Y | 5* (+1 page cross) | 6 (always) | Yes |
| 1E | ASL Abs,X | 6* (+1 page cross) | 7 (always) | Yes |
| 5E | LSR Abs,X | 6* (+1 page cross) | 7 (always) | Yes |
| 3E | ROL Abs,X | 6* (+1 page cross) | 7 (always) | Yes |
| 7E | ROR Abs,X | 6* (+1 page cross) | 7 (always) | Yes |
| FE | INC Abs,X | 6* (+1 page cross) | 7 (always) | Yes |
| DE | DEC Abs,X | 6* (+1 page cross) | 7 (always) | Yes |
| B5 | LDA ZP,X | 3 | 4 | Yes |
| B6 | LDX ZP,Y | 3 | 4 | Yes |
| B4 | LDY ZP,X | 3 | 4 | Yes |
| 95 | STA ZP,X | 3 | 4 | Yes |
| 96 | STX ZP,Y | 3 | 4 | Yes |
| 94 | STY ZP,X | 3 | 4 | Yes |

*Note: Current implementation may already account for some of these via opcode table base cycles

---

## Test ROM Expectations

### cpu_dummy_reads.nes
Tests that read-modify-write instructions perform correct dummy operations:
1. Dummy read from indexed address (before correction)
2. Real read
3. Dummy write (original value)
4. Real write (modified value)

**Current Failure:** 0xFF FF FF signature suggests ROM never initializes properly, likely due to incorrect timing causing infinite loop or wrong execution path.

### cpu_dummy_writes_ppumem.nes
Tests that dummy writes to PPU memory have observable side effects (e.g., PPUADDR incrementing).

**Current Failure:** Times out at frame 227, suggesting ROM is stuck in a loop waiting for specific PPU behavior that never occurs due to missing dummy writes or incorrect timing.

---

## Next Steps

1. **Verify Opcode Table Cycles**: Check if base cycle counts in `OPCODE_TABLE` already account for some dummy reads
2. **Implement Dummy Reads**: Add dummy read operations to indexed addressing modes
3. **Distinguish Read/Write**: Write instructions need unconditional dummy reads
4. **Update Zero Page Indexed**: Add dummy reads to ZP,X and ZP,Y modes
5. **Test Incrementally**: Verify each change doesn't break existing tests

---

## References

- `docs/cpu/CPU_TIMING_REFERENCE.md` lines 513-523 (ASL Absolute,X example)
- `docs/cpu/CPU_TIMING_REFERENCE.md` lines 541-550 (Zero Page,X example)
- NESdev Wiki: CPU addressing modes
- nestest.nes golden log (cycle column)

---

**Status:** Analysis complete. Implementation approach selected: Hybrid (Option 3).
**Next:** Review OPCODE_TABLE to determine what changes are already accounted for.
