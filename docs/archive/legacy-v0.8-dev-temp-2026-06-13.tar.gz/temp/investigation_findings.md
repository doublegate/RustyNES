# cpu_dummy_reads.nes Investigation Findings

**Date:** December 20, 2025
**Test:** cpu_dummy_reads.nes (Blargg CPU test)
**Status:** FAIL 0xFF at frame 11

---

## Understanding the Test

### Test Mechanism

The test uses PPU register $2002 (PPU STATUS) which has a critical side effect:
- **Reading $2002 clears the VBlank flag (bit 7)**

Test structure:
1. Call `begin` - waits for VBlank, then delays → VBlank flag is SET
2. Execute instruction that should/shouldn't perform dummy read from $2002
3. Read accumulator and check if bit 7 is SET or CLEAR
   - `jpl test_failed` = fail if bit 7 is 0 (positive)
   - `jmi test_failed` = fail if bit 7 is 1 (minus/negative)

### Test Cases

**Test 2:** PPU mirroring
- Reads $3FFA (should mirror to $2002)
- First read: expects VBlank SET (jpl fails if clear)
- Second read: expects VBlank CLEAR (jmi fails if set)

**Test 3:** LDA abs,X
- `LDA $2000,X` with X=$22 → $2022 (NO page cross)
  - Should NOT dummy read
  - VBlank should remain SET
- `LDA $20E0,X` with X=$22 → $2102 (page cross from $20→$21)
  - Dummy read from: `($20E0 & $FF00) | ($2102 & $00FF) = $2002`
  - VBlank should be CLEAR from dummy read

**Test 4:** STA abs,X
- `STA $2002` - direct write
  - NO dummy read (writes don't clear VBlank)
  - VBlank should remain SET
- `STA $20E0,X` with X=$22 → $2102
  - Dummy READ from $2002 (STA always does dummy read!)
  - VBlank should be CLEAR

**Test 5:** LDA (zp),Y - same pattern as test 3
**Test 6:** STA (zp),Y - same pattern as test 4
**Test 7:** LDA (zp,X) - NO dummy read
**Test 8:** STA (zp,X) - NO dummy read

### Key Insights from Test

1. **LDA/ADC/etc (READ)**: Dummy read ONLY on page cross (conditional)
2. **STA/STX/STY (WRITE)**: Dummy read ALWAYS for indexed modes (unconditional)
3. **INC/DEC/ASL/etc (RMW)**: Dummy read ALWAYS for indexed modes (unconditional)
4. **(zp,X) mode**: NO dummy read for any instruction
5. **(zp),Y mode**: Dummy read behavior same as abs,Y

---

## Our Implementation Status

### PPU Register Handling ✅ CORRECT

**Bus routing** (`/home/parobek/Code/RustyNES/crates/rustynes-core/src/bus.rs:279-281`):
```rust
0x2000..=0x3FFF => {
    let ppu_addr = 0x2000 + (addr & 0x0007);
    self.ppu.read_register(ppu_addr)
}
```
- $3FFA correctly mirrors to $2002 ✓

**PPU read_register** (`/home/parobek/Code/RustyNES/crates/rustynes-ppu/src/ppu.rs:96-116`):
```rust
pub fn read_register(&mut self, addr: u16) -> u8 {
    match addr & 0x07 {
        2 => {  // $2002: PPUSTATUS
            let status = self.status.bits();
            // ... race condition handling ...
            self.status.clear_vblank(); // Reading clears VBlank flag ✓
            self.scroll.read_ppustatus(); // Reset write latch
            status
        }
    }
}
```
- Mirroring every 8 bytes ✓
- Clears VBlank on read ✓

### CPU Dummy Read Implementation

**read_operand()** - ✅ CORRECT (conditional on page_crossed)
```rust
if result.page_crossed {
    let incorrect_addr = (result.base_addr & 0xFF00) | (result.addr & 0x00FF);
    let _ = bus.read(incorrect_addr);
}
```

**write_operand()** - ✅ CORRECT (unconditional for indexed modes)
```rust
match mode {
    AddressingMode::AbsoluteX | AddressingMode::AbsoluteY | AddressingMode::IndirectIndexedY => {
        let incorrect_addr = (result.base_addr & 0xFF00) | (result.addr & 0x00FF);
        let _ = bus.read(incorrect_addr);  // ✓ Fixed from bus.write()
    }
    _ => {}
}
```

**RMW instructions** - ✅ CORRECT (unconditional for indexed modes)
```rust
// Added to INC, DEC, ASL, LSR, ROL, ROR, DCP, ISC, SLO, RLA, SRE, RRA
match mode {
    AddressingMode::AbsoluteX | AddressingMode::AbsoluteY | AddressingMode::IndirectIndexedY => {
        let incorrect_addr = (result.base_addr & 0xFF00) | (result.addr & 0x00FF);
        let _ = bus.read(incorrect_addr);
    }
    _ => {}
}
```

### Reference: Pinky Emulator Approach

Pinky uses separate addressing modes to encode dummy read behavior:

**READ instructions:** Use `addx`, `addy`, `indirect_indexed` (no _EC suffix)
**WRITE instructions:** Use `addx_EC`, `addy_EC`, `indirect_indexed_EC` (_EC = Extra Cycle forced)
**RMW instructions:** Use `addx_EC` (Extra Cycle forced)

The `is_extra_cycle_forced()` flag controls whether dummy fetch happens:
```rust
if unfixed_target != target || self.state().decoded.is_extra_cycle_forced() {
    self.dummy_fetch( unfixed_target as Address );
}
```

Our approach handles this in instruction/operand methods instead of encoding it in addressing modes. **Both approaches should produce identical behavior.**

---

## Potential Issues

### 1. Timing Difference

**Pinky:** Dummy fetch happens DURING address resolution (inside `memop_indexed()`)
**RustyNES:** Dummy read happens AFTER address resolution (in `write_operand()`/RMW instructions)

**Impact:** If there are cycle-sensitive side effects, the timing might matter. However, for basic register reads this should not cause test failure.

### 2. Missing (zp,X) Check

The test explicitly checks that `(zp,X)` mode does NOT perform dummy reads (tests 7 & 8).

**Our code:** `write_operand()` only matches on:
- `AbsoluteX`
- `AbsoluteY`
- `IndirectIndexedY`

**Missing:** `IndexedIndirectX` (which is `(zp,X)`)

But wait - we DON'T want dummy reads for `(zp,X)`, so NOT including it is correct! ✓

### 3. Unknown Issue

The test fails at frame 11 with 0xFF status, which is very early. This suggests:
- Test might be failing before even reaching the main test cases
- Possible issue with test framework initialization
- Possible issue unrelated to dummy reads

---

## Next Steps

### Option A: Add Targeted Debug Logging
Add logging to verify:
1. VBlank flag is being set after `begin`
2. Dummy reads are actually happening at correct addresses
3. VBlank flag is being cleared by dummy reads to $2002

### Option B: Minimal Reproduction
Create a minimal test that:
1. Sets VBlank flag
2. Performs `STA $20E0,X` with X=$22
3. Checks if VBlank was cleared

### Option C: Check Test Framework
Verify the test ROM actually starts executing correctly:
- Check initial PC
- Check ROM loading
- Check test framework initialization

### Option D: Run Reference Emulator
Run cpu_dummy_reads.nes on Pinky or another emulator with debug output to compare bus access patterns.

---

## Conclusion

Our implementation appears **logically correct** based on:
1. ✅ 6502 hardware specification
2. ✅ Reference implementation analysis (Pinky)
3. ✅ PPU register side effects implemented
4. ✅ Dummy read address formula verified
5. ✅ Code compiles with no warnings

The test failure at frame 11 with 0xFF suggests either:
- Very early failure in test framework setup
- Subtle timing issue we haven't identified
- Integration problem between components

**Recommended:** Proceed with Option A (debug logging) to observe actual runtime behavior.
