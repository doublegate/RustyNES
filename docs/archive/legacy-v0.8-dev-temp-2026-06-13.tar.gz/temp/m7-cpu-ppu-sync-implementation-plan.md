# CPU/PPU Synchronization Implementation Plan

**Created:** 2025-12-20
**Sprint:** M7-S2 (PPU Accuracy)
**Goal:** Achieve ±2 cycle VBlank timing precision

---

## Problem Statement

The PPU timing tests (ppu_02-vbl_set_time.nes and ppu_03-vbl_clear_time.nes) require ±2 cycle accuracy for VBlank flag set/clear timing. Currently:

- **ppu_02-vbl_set_time.nes:** IGNORED (±51 cycles, target: ±2)
- **ppu_03-vbl_clear_time.nes:** IGNORED (±10 cycles, target: ±2)

## Root Cause Analysis

### Current Implementation

The test ROM runner (`crates/rustynes-ppu/tests/ppu_test_roms.rs`) uses instruction-level synchronization:

```rust
// In the main loop:
let cycles = cpu.step(&mut bus);  // Execute full instruction (e.g., 4 cycles)
let _nmi = bus.step_ppu(cycles);  // Step PPU 12 dots (4 cycles × 3 dots/cycle)
```

**Problem:** The PPU steps happen AFTER the CPU instruction completes, not interleaved with it.

### Example Race Condition

Consider this scenario:

1. CPU at scanline 241, dot 0 (just before VBlank)
2. CPU executes `LDA $2002` (4 cycles = 12 PPU dots)
3. PPU steps 12 dots at once: dot 0 → dot 12
4. VBlank flag is set at dot 1, but the $2002 read happened "before" the PPU stepped

**Result:** The CPU might read the VBlank flag at the wrong time, causing ±10-51 cycle inaccuracy.

### Hardware Behavior

On real NES hardware:

- CPU and PPU run in parallel
- PPU steps 3 dots for every 1 CPU cycle
- If CPU reads $2002 on the exact cycle VBlank is set (scanline 241, dot 1):
  - VBlank flag is cleared (normal behavior)
  - NMI is suppressed (race condition side effect)

## Solution Approach

### Cycle-Accurate Interleaving

Instead of stepping the PPU after each instruction, we need to step the PPU after each CPU cycle:

```rust
// Pseudocode
for cpu_cycle in instruction {
    // Step PPU 3 dots
    for _ in 0..3 {
        let (frame_complete, nmi) = ppu.step();
        // Handle NMI
    }

    // Execute 1 CPU cycle worth of work
    cpu.execute_cycle();
}
```

### Challenge: CPU Cycle Granularity

The current CPU implementation executes entire instructions atomically and returns total cycles:

```rust
pub fn step(&mut self, bus: &mut impl Bus) -> u8 {
    // ... fetch opcode, execute instruction ...
    let total_cycles = info.cycles + extra_cycles;
    total_cycles  // Return total
}
```

**Solution:** For test ROMs, we can simulate cycle-level interleaving by:

1. Execute the CPU instruction (get total cycles)
2. Step the PPU 1 dot at a time (total_cycles × 3 dots)
3. Check for $2002 reads and handle race conditions

## Implementation Steps

### Step 1: Cycle-Accurate Test Bus

Modify `crates/rustynes-ppu/tests/ppu_test_roms.rs`:

```rust
impl TestBus {
    /// Step PPU by 1 dot at a time for maximum accuracy
    fn step_ppu_cycle_accurate(&mut self, cpu_cycles: u8) -> bool {
        let mut nmi_triggered = false;
        let ppu_steps = (cpu_cycles as u32) * 3;

        for dot in 0..ppu_steps {
            let (frame_complete, nmi) = self.ppu.step();

            if nmi {
                nmi_triggered = true;
            }

            // Check for race condition at VBlank set
            if self.ppu.scanline() == 241 && self.ppu.dot() == 1 {
                // If CPU is reading $2002 on this exact dot, handle race condition
                // (This will be detected by read_register call timing)
            }
        }

        nmi_triggered
    }
}
```

### Step 2: $2002 Read Race Condition Handling

Add race condition detection in PPU:

```rust
// In crates/rustynes-ppu/src/ppu.rs

impl Ppu {
    pub fn read_register(&mut self, addr: u16) -> u8 {
        match addr {
            0x2002 => {
                let status = self.status.to_byte();

                // Race condition: Reading $2002 on exact cycle VBlank is set
                if self.timing.scanline == 241 && self.timing.dot == 1 {
                    // Suppress NMI if reading on VBlank set cycle
                    self.nmi_pending = false;
                }

                self.status.clear_vblank();
                self.scroll.reset_latch();
                status
            }
            // ... other registers ...
        }
    }
}
```

### Step 3: PPU Timing Accessors

Add public accessors for scanline/dot (if not already present):

```rust
// In crates/rustynes-ppu/src/ppu.rs

impl Ppu {
    /// Get current scanline
    pub fn scanline(&self) -> u16 {
        self.timing.scanline
    }

    /// Get current dot
    pub fn dot(&self) -> u16 {
        self.timing.dot
    }
}
```

### Step 4: Integration Test Validation

Run the test ROMs with cycle-accurate synchronization:

```bash
# Remove #[ignore] attributes and run tests
cargo test --package rustynes-ppu test_ppu_vbl_set_time -- --nocapture
cargo test --package rustynes-ppu test_ppu_vbl_clear_time -- --nocapture
```

## Expected Results

After implementation:

- ✅ ppu_02-vbl_set_time.nes: PASSING (±2 cycle accuracy)
- ✅ ppu_03-vbl_clear_time.nes: PASSING (±2 cycle accuracy)
- ✅ No regressions in existing tests (ppu_vbl_basics, sprite_hit_basics, sprite_hit_alignment)

## Performance Considerations

**Impact:** Cycle-accurate interleaving is ONLY for test ROMs.

The main emulator (`rustynes-core`, `rustynes-desktop`) will continue to use optimized synchronization:

```rust
// In full emulator (rustynes-core)
let cpu_cycles = cpu.step(&mut bus);
let ppu_cycles = cpu_cycles * 3;
for _ in 0..ppu_cycles {
    ppu.step();
}
```

**Reason:** Test ROMs need exact cycle accuracy for validation. Real games tolerate instruction-level synchronization for better performance.

## Timeline

- **Step 1-2:** Implement cycle-accurate test bus + race condition handling (2-3 hours)
- **Step 3:** Add PPU accessors (15 minutes)
- **Step 4:** Test and validate (1-2 hours)
- **Total:** 3-5 hours

## Success Criteria

1. ✅ ppu_02-vbl_set_time.nes passes (result = 0x00)
2. ✅ ppu_03-vbl_clear_time.nes passes (result = 0x00)
3. ✅ All existing PPU tests still pass
4. ✅ No regressions in CPU tests
5. ✅ No performance impact on main emulator

## References

- **PPU Timing:** `/home/parobek/Code/RustyNES/docs/ppu/PPU_TIMING.md`
- **PPU Timing Diagram:** `/home/parobek/Code/RustyNES/docs/ppu/PPU_TIMING_DIAGRAM.md`
- **Test ROMs:** `/home/parobek/Code/RustyNES/test-roms/ppu/`
- **Current Implementation:** `/home/parobek/Code/RustyNES/crates/rustynes-ppu/tests/ppu_test_roms.rs`

---

**Next:** Begin implementation of cycle-accurate test bus
