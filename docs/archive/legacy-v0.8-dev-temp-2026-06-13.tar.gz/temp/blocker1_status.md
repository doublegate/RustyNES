# CPU Dummy Read/Write Implementation Status

## Date: December 20, 2025
## Branch: cycle-cycle

## Summary

Implemented hardware-accurate dummy READ and WRITE cycles for 6502 indexed addressing modes. Code compiles cleanly, logic appears correct, but tests still failing.

## Changes Made

### 1. Fixed write_operand() (cpu.rs lines 1528-1553)
**Issue**: Was doing dummy WRITE instead of dummy READ
**Fix**: Changed `bus.write(incorrect_addr, value)` to `bus.read(incorrect_addr)`
**Behavior**: Write instructions (STA, STX, STY, SAX) now do dummy READ always for AbsoluteX/Y/IndirectIndexedY

### 2. Added dummy READ to all 12 RMW instructions (instructions.rs)
**Affected instructions**: INC, DEC, ASL, LSR, ROL, ROR (official) + DCP, ISC, SLO, RLA, SRE, RRA (unofficial)
**Behavior**: RMW instructions now do dummy READ always for indexed modes (not conditional on page crossing)
**Implementation**: Added match block after address resolution:
```rust
match mode {
    AddressingMode::AbsoluteX | AddressingMode::AbsoluteY | AddressingMode::IndirectIndexedY => {
        let incorrect_addr = (result.base_addr & 0xFF00) | (result.addr & 0x00FF);
        let _ = bus.read(incorrect_addr);
    }
    _ => {}
}
```

### 3. Dummy WRITE already implemented
All RMW instructions already had: `bus.write(addr, value); // Dummy write`
This writes original value before writing modified value.

## Current Test Results (11/20 passing, 55%)

### Passing (11 tests):
1. cpu_instr_01_implied ✓
2. cpu_instr_02_immediate ✓
3. cpu_instr_03_zero_page ✓
4. cpu_instr_04_zp_xy ✓
5. cpu_instr_05_absolute ✓
6. cpu_instr_07_ind_x ✓
7. cpu_instr_08_ind_y ✓
8. cpu_instr_09_branches ✓
9. cpu_instr_10_stack ✓
10. cpu_instr_11_special ✓
11. cpu_branch_timing_2 ✓

### Failing (9 tests):
1. **cpu_dummy_reads** - FAIL 0xFF (Priority 1 blocker)
2. **cpu_instr_06_abs_xy** - TIMEOUT (Priority 2 blocker)
3. **cpu_dummy_writes_ppumem** - FAIL "CPU does 2x writes properly"
4. cpu_all_instrs - TIMEOUT
5. cpu_official_only - TIMEOUT
6. cpu_instr_timing - TIMEOUT
7. cpu_instr_timing_1 - TIMEOUT
8. cpu_dummy_writes_oam - TIMEOUT
9. cpu_interrupts - FAIL "APU should generate IRQ" (known APU issue)

## Technical Analysis

### Dummy Read Address Formula
```rust
incorrect_addr = (base_addr & 0xFF00) | (addr & 0x00FF)
```

**Verification (all cases correct)**:
- No page cross: `LDA $1234,X` (X=$10) → dummy reads $1244 (same as final)
- Page cross: `LDA $12FF,X` (X=$02) → dummy reads $1201, final reads $1301
- Edge case: `LDA $0000,X` (X=$10) → dummy reads $0010
- Edge case: `LDA $00FF,X` (X=$01) → dummy reads $0000, final reads $0100

### Implementation Correctness

✅ READ instructions (read_operand): Dummy read only on page_crossed
✅ WRITE instructions (write_operand): Dummy read ALWAYS for indexed modes
✅ RMW instructions: Dummy read ALWAYS + dummy write of original value
✅ Address formula handles all edge cases including $0000 base address
✅ No clippy warnings
✅ Code compiles cleanly

### Execution Path Verified

Console::step_frame() →
  Console::step() →
    CPU::step() →
      CPU::execute_opcode() →
        Instruction methods (lda, sta, inc, etc.) →
          read_operand() / write_operand() / direct bus access

All instruction methods ARE being called with fixes applied.

## Remaining Issues

### Priority 1: cpu_dummy_reads.nes (Status 0xFF)
**Symptom**: Test fails immediately (frame 11) with 0xFF status
**Expected**: Test checks dummy READ behavior for indexed addressing
**Analysis**:
- Implementation logic is correct per 6502 specification
- Address formula verified mathematically correct
- Dummy reads happening at correct points in instruction execution

**Possible causes**:
1. Test ROM may check for very specific bus access patterns we're not matching
2. Test may be sensitive to cycle timing (but we're not in cycle-accurate mode)
3. Unknown instrumented address ranges that detect incorrect behavior
4. Issue with how Blargg test framework integrates with our emulator

### Priority 2: cpu_instr_06_abs_xy.nes (Timeout)
**Symptom**: Test times out after 300 frames without completion
**Expected**: Tests absolute indexed addressing modes (AbsoluteX, AbsoluteY)
**Analysis**:
- Not an infinite loop (frames ARE completing)
- Test likely waiting for expected behavior that never occurs
- Suggests absolute indexed instructions aren't working correctly

**This is concerning** because:
- Our implementation SHOULD be correct
- Other indexed modes (cpu_instr_07_ind_x, cpu_instr_08_ind_y) PASS
- Only absolute indexed modes fail

**Possible causes**:
1. Test expects specific dummy read pattern not being generated
2. Issue with AbsoluteX/Y resolution in addressing.rs
3. Test checking for edge case we're not handling
4. Interaction between dummy reads and test ROM instrumentation

### Priority 3: cpu_dummy_writes_ppumem.nes
**Symptom**: "CPU does 2x writes properly" - RMW dummy write issue
**Analysis**: RMW instructions DO have `bus.write(addr, value); // Dummy write`
**Possible cause**: Timing or ordering of the dummy write relative to other operations

## Next Investigation Steps

### Option A: Add Debug Logging
Add bus read/write logging to trace exact access patterns for failing tests.
Compare against expected patterns from Visual6502 or other reference.

### Option B: Test Minimal Case
Create minimal test ROM that does single AbsoluteX instruction.
Verify dummy read happens with expected address.

### Option C: Review Reference Implementations
Check TetaNES, Pinky, or other Rust emulators for their dummy read implementation.
Compare implementation details.

### Option D: Consult Test Documentation
Search for cpu_dummy_reads source or documentation.
Understand what specific behavior it's testing.

### Option E: Bisect Changes
Temporarily remove dummy read implementation.
Verify if cpu_instr_06_abs_xy passes without it.
If yes, issue is in dummy read logic.
If no, unrelated issue causing timeout.

## Code Quality

✅ No compilation errors
✅ No clippy warnings
✅ Formula verified mathematically
✅ Logic matches 6502 specification
✅ All edge cases considered

## Conclusion

Implementation appears technically correct but tests are failing. This suggests either:
1. Subtle bug in implementation not visible from code review
2. Test ROM expectations we don't understand
3. Integration issue with test framework
4. Missing piece of 6502 behavior not documented in standard references

**Recommendation**: Proceed with Option E (bisect) to isolate whether dummy reads are causing the failures, then Option A (debug logging) to understand exact bus access patterns.
