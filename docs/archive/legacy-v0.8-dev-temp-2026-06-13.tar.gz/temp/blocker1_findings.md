# BLOCKER 1: Investigation Update - December 20, 2025

## Summary of Findings

### Initial Analysis (blocker1_analysis.md)
- **Root Cause Identified:** OLD `Cpu::step()` method missing dummy reads for indexed addressing
- **Solution Proposed:** Use NEW `Cpu::tick()` cycle-accurate method
- **Assumption:** tick() method is complete and correct

### New Discovery
**CRITICAL:** The `tick()` method has NEVER been tested or validated!

Evidence:
1. `step_frame_accurate()` defined but NEVER USED in codebase
2. No tests exist that use `tick()` method
3. When `step_frame_accurate()` is used in Blargg tests, ALL tests fail with status 0xFF at frame 11
4. This includes tests that previously passed with `step_frame()`

### Test Results

| Method | Tests Passing | Notes |
|--------|---------------|-------|
| `step_frame()` (OLD) | 11/20 (55%) | Works but missing dummy reads |
| `step_frame_accurate()` (NEW) | 0/20 (0%) | All fail with status 0xFF at frame 11 |

Status 0xFF indicates test ROM not initializing - systematic failure in tick() implementation.

## Root Cause Analysis

### Why tick() Fails

The cycle-accurate `tick()` method was implemented but never integrated or validated:

1. **Never Called:** `step_frame_accurate()` exists but has no callers
2. **Never Tested:** No unit or integration tests for tick() execution path
3. **Implementation Issues:** Unknown bugs causing systematic failure at frame 11

### Why step() Works (Partially)

The OLD `step()` method:
- ✅ Correctly executes 256 opcodes (nestest.nes passes)
- ✅ Correct cycle counts in opcode table
- ✅ Correct page crossing detection
- ❌ Missing dummy read bus accesses
- ❌ Missing RMW dummy write bus accesses

### Why Dummy Reads Matter

From CPU_TIMING_REFERENCE.md:

**Indexed Addressing Page Crossing:**
```
LDA $1234,X with X=$10, page cross ($1234 → $1244):

Cycle 1: Fetch opcode
Cycle 2: Fetch low byte ($34)
Cycle 3: Fetch high byte ($12)
Cycle 4: DUMMY READ from $1244 (incorrect page) ← MISSING in step()!
Cycle 5: Read from $1244 (correct address)
```

**Why This Breaks Tests:**
- Self-modifying code depends on dummy read triggering side effects
- Memory-mapped hardware registers change state on read access
- Mappers detect bus activity for banking/IRQ logic

## Solution Options Analysis

### Option A: Fix tick() Method (NOT RECOMMENDED)
**Complexity:** HIGH - Unknown bugs, never tested
**Risk:** HIGH - Could introduce regressions
**Time:** Unknown - Requires full validation
**Status:** tick() is incomplete/broken implementation

### Option B: Add Dummy Reads to resolve() (NOT FEASIBLE)
**Problem:** resolve() must return immediately, can't perform reads
**Complexity:** VERY HIGH - Requires full architecture refactor
**Risk:** VERY HIGH - Breaks entire addressing mode system

### Option C: Modify Instruction Execution (RECOMMENDED)
**Approach:** Add dummy reads in instruction handlers for affected addressing modes
**Complexity:** MEDIUM - Targeted changes to specific instructions
**Risk:** MEDIUM - Affects only indexed addressing instructions
**Time:** 2-4 hours implementation + testing

### Option D: Hybrid Approach
**Approach:** Fix step() to perform dummy reads for indexed modes only
**Complexity:** MEDIUM - Modify step() to detect and handle indexed modes specially
**Risk:** MEDIUM - Localized to step() method
**Time:** 3-5 hours implementation + testing

## Recommended Path Forward

### Phase 1: Targeted Fix for Indexed Addressing (Option C)

**Affected Instructions:**
- LDA/LDX/LDY/STA/STX/STY with AbsoluteX/AbsoluteY
- LDA/STA with IndirectIndexedY
- LDA/STA with IndexedIndirectX (already works - no page cross)

**Implementation:**

1. **Modify `Cpu::step()` to detect indexed addressing**
```rust
pub fn step(&mut self, bus: &mut impl Bus) -> u8 {
    // ... existing code ...

    let info = &OPCODE_TABLE[opcode as usize];
    let addr_result = info.addr_mode.resolve(bus, self.pc, self.x, self.y);

    // Perform dummy read for indexed addressing with page crossing
    if addr_result.page_crossed {
        match info.addr_mode {
            AddressingMode::AbsoluteX | AddressingMode::AbsoluteY | AddressingMode::IndirectIndexedY => {
                // Dummy read from incorrect address before page fix
                let base = /* calculate base address */;
                let incorrect_addr = (base & 0xFF00) | (addr_result.addr & 0x00FF);
                let _ = bus.read(incorrect_addr);
            }
            _ => {}
        }
    }

    // ... rest of instruction execution ...
}
```

2. **Track base address in AddressResult**
```rust
pub struct AddressResult {
    pub addr: u16,
    pub page_crossed: bool,
    pub base_addr: u16,  // NEW: for dummy read calculation
}
```

3. **Update resolve() to return base address**

### Phase 2: Validation

1. Test cpu_instr_06_abs_xy.nes (should pass)
2. Test cpu_instr_07_ind_x.nes (should pass)
3. Test cpu_instr_08_ind_y.nes (should pass)
4. Verify 11 passing tests don't regress
5. Run full Blargg suite - target 17-18/20 (85-90%)

### Phase 3: tick() Investigation (Future Work)

**Defer to later:** Investigate and fix tick() method as separate effort
- Full debugging of state machine
- Unit tests for each state transition
- Integration tests for tick() execution
- Validation against nestest.nes in cycle-accurate mode

## Conclusion

**Current Strategy:** Do NOT use tick() method (broken, never tested)
**Recommended Fix:** Add dummy reads to step() method for indexed addressing
**Expected Outcome:** Fix 9 failing tests (cpu_instr_06/07/08, cpu_dummy_reads, others)
**Success Criteria:** 17-18/20 Blargg tests passing (85-90%)

**Critical Discovery:** The cycle-accurate implementation exists but was never completed.
This explains why the tests fail - it's not a simple integration issue, the tick() method itself has bugs.
