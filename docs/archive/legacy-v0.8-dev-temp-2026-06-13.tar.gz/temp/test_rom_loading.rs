// Temporary test to check ROM loading and reset behavior
use rustynes_core::Console;
use std::fs;

fn main() {
    println!("=== Testing ROM Loading ===\n");

    // Test cpu_instr_01_implied.nes (PASSING)
    println!("--- cpu_instr_01_implied.nes (Mapper 0) ---");
    let rom1 = fs::read("test-roms/cpu/cpu_instr_01_implied.nes").expect("Failed to read ROM 1");
    match Console::from_rom_bytes(&rom1) {
        Ok(console) => {
            println!("✓ ROM loaded successfully");
            println!("  Mapper: created");
            println!("  Console: initialized");

            // Check if we can read PRG-ROM data
            println!("  Test: attempting to access console state...");
        }
        Err(e) => {
            println!("✗ Failed to load ROM: {}", e);
        }
    }

    println!();

    // Test cpu_dummy_reads.nes (FAILING)
    println!("--- cpu_dummy_reads.nes (Mapper 3) ---");
    let rom2 = fs::read("test-roms/cpu/cpu_dummy_reads.nes").expect("Failed to read ROM 2");
    match Console::from_rom_bytes(&rom2) {
        Ok(console) => {
            println!("✓ ROM loaded successfully");
            println!("  Mapper: created");
            println!("  Console: initialized");

            // Check if we can read PRG-ROM data
            println!("  Test: attempting to access console state...");
        }
        Err(e) => {
            println!("✗ Failed to load ROM: {}", e);
        }
    }

    println!("\n=== Test Complete ===");
}
